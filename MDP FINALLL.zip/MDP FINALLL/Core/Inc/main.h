/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define BIN1_Pin GPIO_PIN_5
#define BIN1_GPIO_Port GPIOE
#define BIN2_Pin GPIO_PIN_6
#define BIN2_GPIO_Port GPIOE
#define LED_3_Pin GPIO_PIN_8
#define LED_3_GPIO_Port GPIOE
#define Ultrasonic_Trig_Pin GPIO_PIN_14
#define Ultrasonic_Trig_GPIO_Port GPIOB
#define Ultrasonic_Echo_Pin GPIO_PIN_15
#define Ultrasonic_Echo_GPIO_Port GPIOB
#define PWMA_Pin GPIO_PIN_6
#define PWMA_GPIO_Port GPIOC
#define Servo_Pin GPIO_PIN_7
#define Servo_GPIO_Port GPIOC
#define PWMB_Pin GPIO_PIN_8
#define PWMB_GPIO_Port GPIOC
#define EncoderA_CH1_Pin GPIO_PIN_15
#define EncoderA_CH1_GPIO_Port GPIOA
#define EncoderA_CH2_Pin GPIO_PIN_3
#define EncoderA_CH2_GPIO_Port GPIOB
#define EncoderB_CH1_Pin GPIO_PIN_4
#define EncoderB_CH1_GPIO_Port GPIOB
#define EncoderB_CH2_Pin GPIO_PIN_5
#define EncoderB_CH2_GPIO_Port GPIOB
#define AIN2_Pin GPIO_PIN_8
#define AIN2_GPIO_Port GPIOB
#define AIN1_Pin GPIO_PIN_9
#define AIN1_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
