/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "oled.h"
#include <stdbool.h>
#include <stdarg.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
// ==== encoder math (TUNE THESE) ====
#define WHEEL_DIAMETER_CM   6.55f          // your wheel diameter
#define ENCODER_PPR         30             // pulses/rev from encoder *after gearbox if on motor shaft; else raw
#define QUADRATURE_X        4             // x4 if both channels, rising edges → leave 4
#define GEAR_RATIO 11
#define TICKS_PER_REV  (ENCODER_PPR * QUADRATURE_X * GEAR_RATIO)
#define CM_PER_REV     (3.1415926f * WHEEL_DIAMETER_CM)
#define TICKS_PER_CM   ((float)TICKS_PER_REV / CM_PER_REV)
#define ENC_R_DIR (-1)
#define ENC_L_DIR (+1)


// Simple smoothing (EMA) + hysteresis thresholds
#define R_CLOSE_MAX 20.0f
#define R_OPEN_MIN  24.0f
#define L_CLOSE_MAX 20.0f
#define L_OPEN_MIN  24.0f
#define EMA_A 0.4f

#define MOTOR_A_INVERT 1
#define MOTOR_B_INVERT 0

  osMutexId_t i2cMutex;    // protect I2C (gyro)
  osMutexId_t oledMutex;   // protect OLED (I2C too)
  osMutexId_t driveMutex;  // protect Drive_set() / motor PWMs
  osMutexId_t angleMutex;  // protect turn_angle

//PID
#define Kp 3.0
#define Ki 0.3
#define Kd 0.1 * Kp

//SERVO
#define SERVO_LEFT     1000   // 1 ms , 1000
#define SERVO_STRAIGHT 1500   // 1.5 ms , 1500
#define SERVO_RIGHT    2000   // 2 ms , 2000

//UART
#define RX_BUF_SIZE 6   // maximum message length
#define CMD_BUF_SIZE 32
char cmd_buffer[CMD_BUF_SIZE];
uint8_t cmd_index = 0;
osMessageQueueId_t uartQueue;
osMessageQueueId_t motorQueue;

//IR SENSORS

#define IR_FILTER_LEN 5  // adjust for more or less smoothing

// ------- Global IR Distances ------------
volatile float g_irLeftDist = 0.0f;
volatile float g_irRightDist = 0.0f;
char g_last_turn_dir = 0;   // 0 means undefined


// --- Filter buffers ---
static uint16_t ir1_buf[IR_FILTER_LEN] = {0};
static uint16_t ir2_buf[IR_FILTER_LEN] = {0};
static int ir1_idx = 0, ir2_idx = 0;


// RADIUS
// === Turn geometry & asymmetry (no pivot) ===
#define WHEELBASE_CM   20.0f
#define TRACK_CM       16.0f
#define MAX_STEER_DEG  28.0f
#define PI_F           3.14159265358979f

// measured servo → wheel-angle scale (leave as-is if already tuned)
#define LEFT_STEER_SCALE   0.85f
#define RIGHT_STEER_SCALE  1.12f

// === SERVO COMMAND MAPPING (controls how aggressively servo turns) ===
#define RIGHT_CMD_GAIN   1.65f    // Much more aggressive servo angle
#define RIGHT_GAMMA      0.70f    // Stronger curve - more turn at small angles
#define LEFT_CMD_GAIN    1.00f
#define LEFT_GAMMA       1.00f

// === WHEEL SPEED DIFFERENTIAL (controls inner/outer wheel speed split) ===
#define RIGHT_INNER_GAIN   2.80f   // Inner wheel MUCH slower
#define RIGHT_OUTER_BOOST  1.15f   // Outer wheel a bit faster
#define LEFT_INNER_GAIN    1.00f
#define LEFT_OUTER_BOOST   1.00f
// PWM floors to avoid “hum ? near the end of a turn
#define MIN_TURN_PWM_ABS_FRAC  0.25f   // absolute timer fraction floor


//Distance
// ===== Global obstacle snapshot state =====
volatile int g_first_obstacle_saved  = 0;
volatile int g_second_obstacle_saved = 0;

volatile int32_t g_ticks_at_first_obstacle  = 0;
volatile int32_t g_ticks_at_second_obstacle = 0;

volatile float g_front_gap_at_first_obstacle_cm  = 0.0f;
volatile float g_front_gap_at_second_obstacle_cm = 0.0f;

// optional: maintain a total encoder tick counter
volatile int32_t g_total_encoder_ticks = 0;



/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
 ADC_HandleTypeDef hadc1;
 ADC_HandleTypeDef hadc2;


I2C_HandleTypeDef hi2c2;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;
TIM_HandleTypeDef htim6;
TIM_HandleTypeDef htim8;
TIM_HandleTypeDef htim9;
TIM_HandleTypeDef htim12;

UART_HandleTypeDef huart3;

/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for GyroTask */
osThreadId_t GyroTaskHandle;
const osThreadAttr_t GyroTask_attributes = {
  .name = "GyroTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for MotorTask */
osThreadId_t MotorTaskHandle;
const osThreadAttr_t MotorTask_attributes = {
  .name = "MotorTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for ServoTask */
osThreadId_t ServoTaskHandle;
const osThreadAttr_t ServoTask_attributes = {
  .name = "ServoTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for UARTTask */
osThreadId_t UARTTaskHandle;
const osThreadAttr_t UARTTask_attributes = {
  .name = "UARTTask",
  .stack_size = 512 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* USER CODE BEGIN PV */

/* Create Motor Test task */
osThreadId_t StartMotorTaskHandle;
const osThreadAttr_t StartMotorTask_attributes = {
	.name = "StartMotorTask",
	.stack_size = 1024 * 4,
	.priority = (osPriority_t) osPriorityNormal,
};

/* Create Servo Test task */
osThreadId_t StartServoTaskHandle;
const osThreadAttr_t StartServoTask_attributes = {
	.name = "StartServoTask",
	.stack_size = 128 * 4,
	.priority = (osPriority_t) osPriorityNormal,
};

/* Definitions for gyroTask */
osThreadId_t StartGyroTaskHandle;
const osThreadAttr_t StartGyroTask_attributes = {
  .name = "StartGyroTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};

osThreadId_t CommandHandlerTaskHandle;
const osThreadAttr_t CommandHandlerTask_attributes = {
  .name = "CommandHandlerTask",
  .stack_size = 1024 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};

osThreadId_t UltrasonicTaskHandle;
const osThreadAttr_t UltrasonicTask_attributes = {
  .name = "UltrasonicTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};

osThreadId_t IRSensorTaskHandle;
const osThreadAttr_t IRSensorTask_attributes = {
  .name = "IRSensorTask",
  .stack_size = 1024 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};


// OLED task
osThreadId_t OledTaskHandle;
const osThreadAttr_t OledTask_attributes = {
  .name = "OledTask",
  .stack_size = 512 * 4,
  .priority = (osPriority_t) osPriorityLow,   // drawing isn’t urgent
};


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM8_Init(void);
static void MX_TIM4_Init(void);
static void MX_TIM9_Init(void);
static void MX_I2C2_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_TIM6_Init(void);
static void MX_TIM12_Init(void);
static void MX_ADC1_Init(void);
//static void MX_ADC2_Init(void);
void StartDefaultTask(void *argument);
void StartGyroTask(void *argument);
void StartMotorTask(void *argument);
void StartServoTask(void *argument);
void StartUARTTask(void *argument);
void StartOledTask(void *argument);
void StartCommandHandlerTask(void *argument);
/* USER CODE BEGIN PFP */
void StartMotorTask(void *argument);
void StartServoTask(void *argument);
void StartGyroTask(void  *argument);
void UART_TestEcho(void);
void UARTTask(void *argument);
void UART_Sendf(const char *fmt, ...);
void StartUltrasonicTask(void *argument);

/* --- IR Sensor prototypes --- */
float IR1_GetDistanceCm(void);
float IR2_GetDistanceCm(void);

//void IR_Init(ADC_HandleTypeDef *hadc);
//void IR_ReadAll(void);
//float IR_GetDistance(uint8_t id, uint16_t adc);
//bool IR_IsObstacle(uint8_t id, float threshold_mm);
//void IR_SendUART(UART_HandleTypeDef *huart);
void StartIRSensorTask(void *argument);

void SetServoPosition(int pwmValue);
void TurnForward(int angle_deg, uint16_t duty);
void TurnBackward(int angle_deg, uint16_t duty);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

//GYROSCOPE VARIABLES
uint8_t ICMAddress = 0x68;
int16_t gyroZ;
//volatile long long turn_angle = 0;
volatile float turn_angle = 0.0f;
int16_t prev_angular_velocity = 0;
//int offset = 0;
uint8_t gyroBuffer[20]; //gyro buffer
double total_angle=0;

//UART VARIABLES
uint8_t rx_buffer[6];
uint8_t rx_byte;
uint8_t rx_index = 0;
osMutexId_t adc1Mutex;


// ULTRASONIC GLOBALS (ADD THESE HERE!)
volatile uint32_t tc1 = 0, tc2 = 0;
volatile uint32_t echo = 0;
volatile uint8_t  is_rising = 1;
volatile uint8_t  echo_ready = 0;
volatile uint32_t isr_count = 0;
volatile float    g_latest_dist_cm = 0.0f;
volatile uint8_t  g_us_valid       = 0;
volatile uint32_t g_us_ts_ms       = 0;
#define US_FRESH_MS 150  // distance must be newer than this
#define US_MAX_RUN_MS 8000  // hard cap so we never run forever
#define US_STOP_MARGIN_CM 8.0f  // extra margin for reaction time

static inline bool us_is_fresh(void) {
    return g_us_valid && ((HAL_GetTick() - g_us_ts_ms) <= US_FRESH_MS);
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM8_Init();
  MX_TIM4_Init();
  MX_TIM9_Init();
  MX_I2C2_Init();
  MX_USART3_UART_Init();
  MX_TIM6_Init();
  MX_TIM12_Init();
  MX_ADC1_Init();
  /* USER CODE BEGIN 2 */


  //OLED
  OLED_Init();

  //UART
  HAL_UART_Receive_IT(&huart3, &rx_byte, 1);   // use single-byte buffer

  //START SERVO MOTOR PWM
  HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_2);

  //IR SENSORS
  //IR_Init(&hadc1);

  //START DC MOTOR ENCODERS
  //HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_ALL);
  //HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_ALL);

  HAL_TIM_Base_Start(&htim6); //timer 6 for delay_us routine
  HAL_TIM_IC_Start_IT(&htim12, TIM_CHANNEL_2);

  //START DC MOTOR PWM
  HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_ALL);
  //motor a
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_3);
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_4);

  //motor b
  HAL_TIM_PWM_Start(&htim9, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim9, TIM_CHANNEL_2);

  /* USER CODE END 2 */

  /* Init scheduler */
  osKernelInitialize();

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  // === MUTEXES ===
  uartQueue  = osMessageQueueNew(16, CMD_BUF_SIZE, NULL);
  motorQueue = osMessageQueueNew(16 , CMD_BUF_SIZE, NULL);
 // adc1Mutex = osMutexNew(NULL);

  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of defaultTask */
  defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);
  OledTaskHandle = osThreadNew(StartOledTask, NULL, &OledTask_attributes);

  /* creation of GyroTask */
 // GyroTaskHandle = osThreadNew(StartGyroTask, NULL, &GyroTask_attributes);

  /* creation of MotorTask */
  //MotorTaskHandle = osThreadNew(StartMotorTask, NULL, &MotorTask_attributes);

  /* creation of ServoTask */
  //ServoTaskHandle = osThreadNew(StartServoTask, NULL, &ServoTask_attributes);

  /* creation of UARTTask */
 // UARTTaskHandle = osThreadNew(StartUARTTask, NULL, &UARTTask_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
//  StartGyroTaskHandle = osThreadNew(StartGyroTask, NULL, &StartGyroTask_attributes);

  //StartServoTaskHandle = osThreadNew(StartServoTask, NULL, &StartServoTask_attributes);

  UARTTaskHandle = osThreadNew(UARTTask, NULL, &UARTTask_attributes);

  //StartMotorTaskHandle = osThreadNew(StartMotorTask, NULL, &StartMotorTask_attributes);

  UltrasonicTaskHandle = osThreadNew(StartUltrasonicTask, NULL, &UltrasonicTask_attributes);

  IRSensorTaskHandle = osThreadNew(StartIRSensorTask, NULL, &IRSensorTask_attributes);

  CommandHandlerTaskHandle = osThreadNew(StartCommandHandlerTask, NULL, &CommandHandlerTask_attributes);
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV2;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_5;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief ADC2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC2_Init(void)
{
  ADC_ChannelConfTypeDef sConfig = {0};

  hadc2.Instance = ADC2;
  hadc2.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV2;
  hadc2.Init.Resolution = ADC_RESOLUTION_12B;
  hadc2.Init.ScanConvMode = DISABLE;
  hadc2.Init.ContinuousConvMode = DISABLE;
  hadc2.Init.DiscontinuousConvMode = DISABLE;
  hadc2.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc2.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc2.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc2.Init.NbrOfConversion = 1;
  hadc2.Init.DMAContinuousRequests = DISABLE;
  hadc2.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc2) != HAL_OK)
  {
    Error_Handler();
  }

  sConfig.Channel = ADC_CHANNEL_4;   // use different channel than ADC1
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C2_Init(void)
{

  /* USER CODE BEGIN I2C2_Init 0 */

  /* USER CODE END I2C2_Init 0 */

  /* USER CODE BEGIN I2C2_Init 1 */

  /* USER CODE END I2C2_Init 1 */
  hi2c2.Instance = I2C2;
  hi2c2.Init.ClockSpeed = 100000;
  hi2c2.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c2.Init.OwnAddress1 = 0;
  hi2c2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c2.Init.OwnAddress2 = 0;
  hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c2.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C2_Init 2 */

  /* USER CODE END I2C2_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 65535;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI12;
  sConfig.IC1Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 0;
  sConfig.IC2Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 0;
  if (HAL_TIM_Encoder_Init(&htim2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 0;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI12;
  sConfig.IC1Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 0;
  sConfig.IC2Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 0;
  if (HAL_TIM_Encoder_Init(&htim3, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 0;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 65535;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */
  HAL_TIM_MspPostInit(&htim4);

}

/**
  * @brief TIM6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM6_Init(void)
{

  /* USER CODE BEGIN TIM6_Init 0 */

  /* USER CODE END TIM6_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM6_Init 1 */

  /* USER CODE END TIM6_Init 1 */
  htim6.Instance = TIM6;
  htim6.Init.Prescaler = 16-1;
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 65535;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM6_Init 2 */

  /* USER CODE END TIM6_Init 2 */

}

/**
  * @brief TIM8 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM8_Init(void)
{

  /* USER CODE BEGIN TIM8_Init 0 */

  /* USER CODE END TIM8_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM8_Init 1 */

  /* USER CODE END TIM8_Init 1 */
  htim8.Instance = TIM8;
  htim8.Init.Prescaler = 16-1;
  htim8.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim8.Init.Period = 65535;
  htim8.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim8.Init.RepetitionCounter = 0;
  htim8.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim8) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim8, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim8) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim8, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim8, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim8, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim8, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim8, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM8_Init 2 */

  /* USER CODE END TIM8_Init 2 */
  HAL_TIM_MspPostInit(&htim8);

}

/**
  * @brief TIM9 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM9_Init(void)
{

  /* USER CODE BEGIN TIM9_Init 0 */

  /* USER CODE END TIM9_Init 0 */

  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM9_Init 1 */

  /* USER CODE END TIM9_Init 1 */
  htim9.Instance = TIM9;
  htim9.Init.Prescaler = 0;
  htim9.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim9.Init.Period = 65535;
  htim9.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim9.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim9) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim9, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim9, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM9_Init 2 */

  /* USER CODE END TIM9_Init 2 */
  HAL_TIM_MspPostInit(&htim9);

}

/**
  * @brief TIM12 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM12_Init(void)
{

  /* USER CODE BEGIN TIM12_Init 0 */

  /* USER CODE END TIM12_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_IC_InitTypeDef sConfigIC = {0};

  /* USER CODE BEGIN TIM12_Init 1 */

  /* USER CODE END TIM12_Init 1 */
  htim12.Instance = TIM12;
  htim12.Init.Prescaler = 16-1;
  htim12.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim12.Init.Period = 65535;
  htim12.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim12.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim12) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim12, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_IC_Init(&htim12) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_BOTHEDGE;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 0;
  if (HAL_TIM_IC_ConfigChannel(&htim12, &sConfigIC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM12_Init 2 */

  /* USER CODE END TIM12_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_3_GPIO_Port, LED_3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(Ultrasonic_Trig_GPIO_Port, Ultrasonic_Trig_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14, GPIO_PIN_RESET);

  /*Configure GPIO pin : LED_3_Pin */
  GPIO_InitStruct.Pin = LED_3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_3_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : Ultrasonic_Trig_Pin */
  GPIO_InitStruct.Pin = Ultrasonic_Trig_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(Ultrasonic_Trig_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PD11 PD12 PD13 PD14 */
  GPIO_InitStruct.Pin = GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pin : IR sensors*/
  GPIO_InitStruct.Pin  = GPIO_PIN_4 | GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}


static inline int parse_u3(const char *p) {
    // parse exactly 3 digits "000".."999" → int, return -1 on bad input
    if (!p) return -1;
    if (p[0]<'0'||p[0]>'9' || p[1]<'0'||p[1]>'9' || p[2]<'0'||p[2]>'9') return -1;
    return (p[0]-'0')*100 + (p[1]-'0')*10 + (p[2]-'0');
}

/* USER CODE BEGIN 4 */
//UART
//void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
//    if (huart->Instance == USART3) {
//        if (rx_byte != '\n' && rx_byte != '\r' && cmd_index < CMD_BUF_SIZE - 1) {
//            cmd_buffer[cmd_index++] = rx_byte;
//        }
//        else if (cmd_index > 0) {  // got terminator, and buffer has something
//            cmd_buffer[cmd_index] = '\0';   // terminate string
//
//            // copy into queue (check result!)
//            if (osMessageQueuePut(uartQueue, cmd_buffer, 0, 0) == osOK) {
//                // success
//            }
//
//            cmd_index = 0; // reset for next command
//        }
//
//        // restart reception
//        HAL_UART_Receive_IT(&huart3, &rx_byte, 1);
//    }
//}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART3) {
        if (rx_byte != '\n' && rx_byte != '\r' && cmd_index < CMD_BUF_SIZE - 1) {
            cmd_buffer[cmd_index++] = rx_byte;
        }
        else if (cmd_index > 0) {  // got full command
            cmd_buffer[cmd_index] = '\0';

            // ✅ make a *local copy* before queueing
            char temp[CMD_BUF_SIZE];
            strcpy(temp, cmd_buffer);

            // try putting into queue (non-blocking)
            if (osMessageQueuePut(uartQueue, temp, 0, 0) != osOK) {
                // queue full — optional: discard or log
            }

            cmd_index = 0;
        }

        // restart next byte interrupt
        HAL_UART_Receive_IT(&huart3, &rx_byte, 1);
    }
}
//void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){
//	if (huart->Instance == USART3)
//	{
//		if (rx_byte != '\n' && rx_index < RX_BUF_SIZE - 1)
//		{
//			// store the received byte
//			rx_buffer[rx_index++] = rx_byte;
//		}
//		else
//		{
//			// end of message, null-terminate
//			rx_buffer[rx_index] = '\0';
//			rx_index = 0;
//
//			// display on OLED
//			OLED_Clear();
//			OLED_ShowString(0, 0, rx_buffer);
//			OLED_Refresh_Gram();
//		}
//
//		// restart reception
//		HAL_UART_Receive_IT(&huart3, &rx_byte, 1);
//	}
//
//	//	UNUSED(huart);
//////	HAL_UART_Transmit(&huart3, "\n\r", 2, 100);
////	HAL_UART_Receive_IT(&huart3, (uint8_t *)rx_buffer, NUM_BYTES_RECIEVE_UART);
//////	HAL_UART_Transmit(&huart3, (uint8_t *)rx_buffer, strlen(rx_buffer), 1);
////
////	dir_command = rx_buffer[0];
////	dist_command = ((rx_buffer[1] - '0') * 10) + (rx_buffer[2] - '0');
////	message_index++;
//////	moveController();
//////	uint8_t displayStr[20];
//////
//////	sprintf(displayStr,"message: %c%d %d",  dir_command, dist_command, message_index);
//////	OLED_Clear();
//////	OLED_ShowString(10, 10, displayStr);
//////	OLED_Refresh_Gram();
////
//////	HAL_UART_Receive_IT(&huart3, (uint8_t *)aRxBuffer, NUM_BYTES_RECIEVE_UART);
//}

//DC MOTOR FUCNTIONS
static inline uint16_t clamp16u(uint16_t v, uint16_t lo, uint16_t hi){ return (v < lo) ? lo : (v > hi) ? hi : v;}

static uint32_t clamp_u32(uint32_t val, uint32_t max) { return (val > max) ? max : val; }

static void MotorA_set(int16_t power) {
  if (MOTOR_A_INVERT) power = -power;
  uint32_t max = htim4.Init.Period;
  uint32_t duty = clamp_u32((power < 0) ? -power : power, max);

  if (power < 0) {
     __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_4, duty);
     __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, 0);
   } else if (power > 0) {
     __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_4, 0);
     __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, duty);
   } else {
     __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_4, 0);
     __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, 0);
   }
}

static void MotorB_set(int16_t power) {
  if (MOTOR_B_INVERT) power = -power;
  uint32_t max = htim9.Init.Period;
  uint32_t duty = clamp_u32((power < 0) ? -power : power, max);

  if (power < 0) {
      __HAL_TIM_SET_COMPARE(&htim9, TIM_CHANNEL_1, duty);
      __HAL_TIM_SET_COMPARE(&htim9, TIM_CHANNEL_2, 0);
    } else if (power > 0) {
      __HAL_TIM_SET_COMPARE(&htim9, TIM_CHANNEL_1, 0);
      __HAL_TIM_SET_COMPARE(&htim9, TIM_CHANNEL_2, duty);
    } else {
      __HAL_TIM_SET_COMPARE(&htim9, TIM_CHANNEL_1, 0);
      __HAL_TIM_SET_COMPARE(&htim9, TIM_CHANNEL_2, 0);
    }
}

int32_t Encoder_Left_Count(void) {
    return (int32_t)__HAL_TIM_GET_COUNTER(&htim2);
}

int32_t Encoder_Right_Count(void) {
    return (int32_t)__HAL_TIM_GET_COUNTER(&htim3);
}

static inline void Drive_set(int16_t left, int16_t right) { MotorA_set(left); MotorB_set(right); }

static inline void MoveForward(uint16_t duty, uint32_t time) {
	Drive_set(duty,duty);
    osDelay(time);
    Drive_set(0,0); //stop
}

static inline void MoveBackward(uint16_t duty_L, uint16_t duty_R, uint32_t time) {
	Drive_set(-duty_L,-duty_R);
    osDelay(time);
    Drive_set(0,0); //stop
}

static inline void MotorA_brake(void){
    uint32_t max = __HAL_TIM_GET_AUTORELOAD(&htim4);       // TIM4 = motor A (back-left or back-right on your board)
    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, max); // IN1 = HIGH
    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_4, max); // IN2 = HIGH
}

static inline void MotorB_brake(void){
    uint32_t max = __HAL_TIM_GET_AUTORELOAD(&htim9);       // TIM9 = motor B (the other rear motor)
    __HAL_TIM_SET_COMPARE(&htim9, TIM_CHANNEL_1, max); // IN1 = HIGH
    __HAL_TIM_SET_COMPARE(&htim9, TIM_CHANNEL_2, max); // IN2 = HIGH
}

static inline void Drive_brake(void){ MotorA_brake(); MotorB_brake(); } //This is used in the case of an abrupt brake

// Drive until ultrasonic distance <= stop_cm (gated by US). forward!=0 => forward, 0 => reverse.
void Drive_UltrasonicGated(int forward, uint16_t duty, float stop_cm, uint32_t max_ms)
{
    const uint32_t dt_ms = 10;
    uint32_t t0 = HAL_GetTick();

    // straight wheels, small settle
    SetServoPosition(SERVO_STRAIGHT);
    osDelay(10);

    // start moving
    int16_t pwm = (int16_t)duty;
    if (!forward) pwm = -pwm;
    Drive_set(pwm, pwm);

    while (1) {
        osDelay(dt_ms);

        // fail-safe stop if US is stale too long or time budget exceeded
        if (!us_is_fresh() || (HAL_GetTick() - t0) > max_ms) {
            Drive_set(0,0);
            SetServoPosition(SERVO_STRAIGHT);
            return;
        }

        // stop when obstacle is at/inside threshold
        if (g_latest_dist_cm <= stop_cm) {
            Drive_brake();
            osDelay(30);
            Drive_set(0,0);
            SetServoPosition(SERVO_STRAIGHT);
            return;
        }
    }
}


void MoveForwardDistance(uint16_t duty, float distance_cm)
{
    if (distance_cm <= 0.0f || duty == 0) return;

    // ===== Fixed loop timing =====
    const uint32_t LOOP_DT_MS = 5;                 // 200 Hz

    // ===== Target from encoders =====
    const int32_t target_ticks = (int32_t)(distance_cm * TICKS_PER_CM + 0.5f);

    // ===== Servo correction (bang-bang style but smoothed) =====
    // Reference-style: keep yaw near start_yaw; push LEFT/RIGHT when error > threshold.
    // We do it with a small proportional trim and slew to avoid oscillations.
    const float  YAW_THRESH_DEG   = 1.0f;          // like your reference
    const float  YAW_HYST_DEG     = 0.5f;          // little hysteresis so it doesn’t flap
    const int    SERVO_CENTER_US  = SERVO_STRAIGHT;
    const int    TRIM_MAX_US      = 140;           // cap trim magnitude
    const int    TRIM_SLEW_US     = 6;             // max change/loop (soft movement)
    const float  TRIM_GAIN_US_PER_DEG = 18.0f;     // how much servo µs per degree of error

    // If your wheels naturally pull one way, put that here (e.g. +8 or -8)
    const int    STATIC_STRAIGHT_OFFSET_US = 0;

    float yaw_start  = turn_angle;
    int   trim_us    = 0;   // our live trim around center (positive = steer LEFT)

    // ===== Make sure we’re stopped, then center =====
    Drive_set(0, 0);
    osDelay(5);
    SetServoPosition(SERVO_CENTER_US + STATIC_STRAIGHT_OFFSET_US);
    osDelay(10);

    // ===== Encoders reset/start =====
    __HAL_TIM_SET_COUNTER(&htim2, 0);
    __HAL_TIM_SET_COUNTER(&htim3, 0);
    HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_ALL);
    HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_ALL);

    uint16_t prev_L = (uint16_t)__HAL_TIM_GET_COUNTER(&htim2);
    uint16_t prev_R = (uint16_t)__HAL_TIM_GET_COUNTER(&htim3);
    int32_t  total_L = 0, total_R = 0;

    // ===== Run motors at fixed duty =====
    Drive_set(duty, duty);

    // Optional: progress watchdog (prevents hanging forever)
    int32_t   last_avg  = 0;
    uint32_t  last_prog = osKernelGetTickCount();
    const uint32_t STALL_MS = 800;

    // ===== Main loop =====
    while (1) {
        osDelay(LOOP_DT_MS);

        // --- encoder deltas (wrap-safe) ---
        uint16_t curr_L = (uint16_t)__HAL_TIM_GET_COUNTER(&htim2);
        uint16_t curr_R = (uint16_t)__HAL_TIM_GET_COUNTER(&htim3);

        int32_t dL = (int32_t)(curr_L - prev_L);
        int32_t dR = (int32_t)(curr_R - prev_R);
        if (dL >  32767) dL -= 65536;  if (dL < -32768) dL += 65536;
        if (dR >  32767) dR -= 65536;  if (dR < -32768) dR += 65536;

        dL *= ENC_L_DIR;   // forward must be positive
        dR *= ENC_R_DIR;

        total_L += dL;
        total_R += dR;
        prev_L = curr_L;
        prev_R = curr_R;

        int32_t avg_pos = (total_L + total_R) / 2;
        if (avg_pos < 0) avg_pos = 0;

        // --- progress watchdog ---
        uint32_t now = osKernelGetTickCount();
        if (avg_pos > last_avg + 3) { last_avg = avg_pos; last_prog = now; }
        else if ((now - last_prog) > STALL_MS) break;

        // --- reference-like yaw correction ---
        // error = current - start (wrap to [-180,180] if your gyro can wrap)
        float yaw_err = turn_angle - yaw_start;
        if (yaw_err > 180.0f)  yaw_err -= 360.0f;
        if (yaw_err < -180.0f) yaw_err += 360.0f;

        // deadband + hysteresis window
        float cmd_err = 0.0f;
        if (yaw_err >  (YAW_THRESH_DEG))          cmd_err = yaw_err - YAW_HYST_DEG;
        else if (yaw_err < -(YAW_THRESH_DEG))     cmd_err = yaw_err + YAW_HYST_DEG;
        // else keep cmd_err = 0 (recenters slowly)

        // proportional trim around center (positive err → steer LEFT)
        int target_trim = (int)lroundf(cmd_err * TRIM_GAIN_US_PER_DEG);

        // clamp trim target
        if (target_trim >  TRIM_MAX_US) target_trim =  TRIM_MAX_US;
        if (target_trim < -TRIM_MAX_US) target_trim = -TRIM_MAX_US;

        // slew toward target for smoothness
        int step = target_trim - trim_us;
        if (step >  TRIM_SLEW_US) step =  TRIM_SLEW_US;
        if (step < -TRIM_SLEW_US) step = -TRIM_SLEW_US;
        trim_us += step;

        // apply trim
        SetServoPosition(SERVO_CENTER_US + STATIC_STRAIGHT_OFFSET_US + trim_us);

        // --- done? ---
        if (avg_pos >= target_ticks) break;
    }

    // ===== Stop & center =====
    Drive_brake();
    SetServoPosition(SERVO_CENTER_US + STATIC_STRAIGHT_OFFSET_US);
    osDelay(10);
}

//void MoveForwardDistance_us(uint16_t duty, float distance_cm)
//{
//    if (distance_cm <= 0.0f || duty == 0) return;
//
//    const uint32_t LOOP_DT_MS = 5;                 // 200 Hz
//    const float    DT         = 0.005f;
//    const int32_t  target_ticks = (int32_t)(distance_cm * TICKS_PER_CM + 0.5f);
//
//    // ===== Servo correction (yours) =====
//    const float  YAW_THRESH_DEG   = 1.0f;
//    const float  YAW_HYST_DEG     = 0.5f;
//    const int    SERVO_CENTER_US  = SERVO_STRAIGHT;
//    const int    TRIM_MAX_US      = 150;
//    const int    TRIM_SLEW_US     = 6;
//    const float  TRIM_GAIN_US_PER_DEG = 18.0f;
//    const int    STATIC_STRAIGHT_OFFSET_US = 0;
//
//    // ===== NEW: wheel-sync (encoder) =====
//    const float  KP_WSYNC   = 0.12f;       // try 0.08–0.18
//    const float  KI_WSYNC   = 0.0020f;     // tiny integral to cancel bias
//    const int16_t I_WSYNC_LIM = 400;       // integral clamp (PWM units)
//    const int16_t CORR_LIM     = 600;      // total correction clamp
//    int32_t err_int = 0;                   // wheel-sync integral
//
//    // ===== Ultrasonic safety =====
//    const float   STOP_CM = 20.0f;
//    const float   SAFETY_MARGIN_CM = 10.0f;
//    const uint8_t CLOSE_THRESHOLD   = 1;
//
//    // ===== Stall protection =====
//    const uint32_t STALL_MS = 800;
//
//    // ===== Setup =====
//    Drive_set(0,0); osDelay(5);
//    SetServoPosition(SERVO_CENTER_US + STATIC_STRAIGHT_OFFSET_US);
//    osDelay(10);
//
//    // Encoders
//    __HAL_TIM_SET_COUNTER(&htim2, 0);
//    __HAL_TIM_SET_COUNTER(&htim3, 0);
//    HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_ALL);
//    HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_ALL);
//
//    uint16_t prev_L = (uint16_t)__HAL_TIM_GET_COUNTER(&htim2);
//    uint16_t prev_R = (uint16_t)__HAL_TIM_GET_COUNTER(&htim3);
//    int32_t  total_L = 0, total_R = 0;
//
//    float    yaw_start = turn_angle;
//    int      trim_us   = 0;
//    uint8_t  close_count = 0;
//
//    int32_t   last_avg  = 0;
//    uint32_t  last_prog = osKernelGetTickCount();
//
//    // Start driving
//    Drive_set(duty, duty);
//
//    while (1) {
//        osDelay(LOOP_DT_MS);
//
//        // ----- US safety -----
//        float current_dist; uint8_t dist_valid;
//        uint32_t primask = __get_PRIMASK();
//        __disable_irq();
//        current_dist = g_latest_dist_cm;
//        dist_valid   = g_us_valid && ((HAL_GetTick() - g_us_ts_ms) <= US_FRESH_MS);
//        __set_PRIMASK(primask);
//
//        if (dist_valid && current_dist <= (STOP_CM + SAFETY_MARGIN_CM)) {
//            if (++close_count >= CLOSE_THRESHOLD) {
//                Drive_brake(); Drive_set(0,0);
//                SetServoPosition(SERVO_CENTER_US + STATIC_STRAIGHT_OFFSET_US);
//                return;
//            }
//        } else close_count = 0;
//
//        // ----- Encoders -----
//        uint16_t curr_L = (uint16_t)__HAL_TIM_GET_COUNTER(&htim2);
//        uint16_t curr_R = (uint16_t)__HAL_TIM_GET_COUNTER(&htim3);
//        int32_t dL = (int32_t)(curr_L - prev_L);
//        int32_t dR = (int32_t)(curr_R - prev_R);
//        if (dL >  32767) dL -= 65536;  if (dL < -32768) dL += 65536;
//        if (dR >  32767) dR -= 65536;  if (dR < -32768) dR += 65536;
//        dL *= ENC_L_DIR;  dR *= ENC_R_DIR;
//        total_L += dL;    total_R += dR;
//        prev_L = curr_L;  prev_R = curr_R;
//
//        int32_t avg_pos = (total_L + total_R) / 2;
//        if (avg_pos < 0) avg_pos = 0;
//
//        // Stall watchdog
//        uint32_t now = osKernelGetTickCount();
//        if (avg_pos > last_avg + 3) { last_avg = avg_pos; last_prog = now; }
//        else if ((now - last_prog) > STALL_MS) break;
//
//        // ----- NEW: Wheel-sync PWM split -----
//        // error > 0 means left advanced vs right → slow left / speed right
//        int32_t err = (total_L - total_R);
//        err_int += err;
//        if (err_int >  I_WSYNC_LIM) err_int =  I_WSYNC_LIM;
//        if (err_int < -I_WSYNC_LIM) err_int = -I_WSYNC_LIM;
//
//        int32_t corr = (int32_t)(KP_WSYNC * err + KI_WSYNC * err_int);
//        if (corr >  CORR_LIM) corr =  CORR_LIM;
//        if (corr < -CORR_LIM) corr = -CORR_LIM;
//
//        int16_t left_pwm  = (int16_t)duty - (int16_t)corr;
//        int16_t right_pwm = (int16_t)duty + (int16_t)corr;
//
//        // keep a small floor so motors don’t stall asymmetrically
//        uint16_t pwm_floor = (uint16_t)(htim8.Init.Period * 0.12f); // ~12%
//        if (left_pwm  < (int16_t)pwm_floor)  left_pwm  = (int16_t)pwm_floor;
//        if (right_pwm < (int16_t)pwm_floor)  right_pwm = (int16_t)pwm_floor;
//
//        Drive_set(left_pwm, right_pwm);
//
//        // ----- Servo heading correction (yours) -----
//        float yaw_err = turn_angle - yaw_start;
//        if (yaw_err > 180.0f)  yaw_err -= 360.0f;
//        if (yaw_err < -180.0f) yaw_err += 360.0f;
//
//        float cmd_err = 0.0f;
//        if (yaw_err >  (YAW_THRESH_DEG))          cmd_err = yaw_err - YAW_HYST_DEG;
//        else if (yaw_err < -(YAW_THRESH_DEG))     cmd_err = yaw_err + YAW_HYST_DEG;
//
//        int target_trim = (int)lroundf(cmd_err * TRIM_GAIN_US_PER_DEG);
//        if (target_trim >  TRIM_MAX_US) target_trim =  TRIM_MAX_US;
//        if (target_trim < -TRIM_MAX_US) target_trim = -TRIM_MAX_US;
//
//        int step = target_trim - trim_us;
//        if (step >  TRIM_SLEW_US) step =  TRIM_SLEW_US;
//        if (step < -TRIM_SLEW_US) step = -TRIM_SLEW_US;
//        trim_us += step;
//        SetServoPosition(SERVO_CENTER_US + STATIC_STRAIGHT_OFFSET_US + trim_us);
//
//        // done?
//        if (avg_pos >= target_ticks) break;
//    }
//
//    Drive_brake();
//    SetServoPosition(SERVO_CENTER_US + STATIC_STRAIGHT_OFFSET_US);
//    osDelay(10);
//}
//
//void MoveForwardDistance_us(uint16_t duty, float distance_cm)
//{
//    if (distance_cm <= 0.0f || duty == 0) return;
//
//    const uint32_t LOOP_DT_MS = 5;                 // 200 Hz
//    const float    DT         = 0.005f;
//    const int32_t  target_ticks = (int32_t)(distance_cm * TICKS_PER_CM + 0.5f);
//
//    // ===== Servo correction =====
//    const float  YAW_THRESH_DEG   = 1.0f;
//    const float  YAW_HYST_DEG     = 0.5f;
//    const int    SERVO_CENTER_US  = SERVO_STRAIGHT;
//    const int    TRIM_MAX_US      = 150;
//    const int    TRIM_SLEW_US     = 6;
//    const float  TRIM_GAIN_US_PER_DEG = 18.0f;
//    const int    STATIC_STRAIGHT_OFFSET_US = 0;
//
//    // ===== Wheel-sync (encoder) =====
//    const float  KP_WSYNC   = 0.12f;
//    const float  KI_WSYNC   = 0.0020f;
//    const int16_t I_WSYNC_LIM = 400;
//    const int16_t CORR_LIM     = 600;
//    int32_t err_int = 0;
//
//    // ===== Ultrasonic safety =====
//    const float   STOP_CM = 25.0f;
//    const float   SAFETY_MARGIN_CM = 10.0f;
//    const uint8_t CLOSE_THRESHOLD   = 1;
//
//    // ===== Stall protection =====
//    const uint32_t STALL_MS = 800;
//
//    // ===== Setup =====
//    Drive_set(0,0); osDelay(5);
//    SetServoPosition(SERVO_CENTER_US + STATIC_STRAIGHT_OFFSET_US);
//    osDelay(10);
//
//    // Encoders
//    __HAL_TIM_SET_COUNTER(&htim2, 0);
//    __HAL_TIM_SET_COUNTER(&htim3, 0);
//    HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_ALL);
//    HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_ALL);
//
//    uint16_t prev_L = (uint16_t)__HAL_TIM_GET_COUNTER(&htim2);
//    uint16_t prev_R = (uint16_t)__HAL_TIM_GET_COUNTER(&htim3);
//    int32_t  total_L = 0, total_R = 0;
//
//    float    yaw_start = turn_angle;
//    int      trim_us   = 0;
//    uint8_t  close_count = 0;
//
//    int32_t   last_avg  = 0;
//    uint32_t  last_prog = osKernelGetTickCount();
//
//    // Start driving
//    Drive_set(duty, duty);
//
//    while (1)
//    {
//        osDelay(LOOP_DT_MS);
//
//        // ----- Ultrasonic safety (HARD STOP) -----
//        float current_dist; uint8_t dist_valid;
//        uint32_t primask = __get_PRIMASK();
//        __disable_irq();
//        current_dist = g_latest_dist_cm;
//        dist_valid   = g_us_valid && ((HAL_GetTick() - g_us_ts_ms) <= US_FRESH_MS);
//        __set_PRIMASK(primask);
//
//        if (dist_valid && current_dist <= (STOP_CM + SAFETY_MARGIN_CM)) {
//            if (++close_count >= CLOSE_THRESHOLD) {
//                Drive_brake();                          // HARD stop immediately
//                SetServoPosition(SERVO_CENTER_US + STATIC_STRAIGHT_OFFSET_US);
//                UART_Sendf("US stop triggered at %.1f cm — HARD STOP\r\n", current_dist);
//                return;                                 // exit instantly
//            }
//        } else close_count = 0;
//
//        // ----- Encoder updates -----
//        uint16_t curr_L = (uint16_t)__HAL_TIM_GET_COUNTER(&htim2);
//        uint16_t curr_R = (uint16_t)__HAL_TIM_GET_COUNTER(&htim3);
//        int32_t dL = (int32_t)(curr_L - prev_L);
//        int32_t dR = (int32_t)(curr_R - prev_R);
//        if (dL >  32767) dL -= 65536;  if (dL < -32768) dL += 65536;
//        if (dR >  32767) dR -= 65536;  if (dR < -32768) dR += 65536;
//        dL *= ENC_L_DIR;  dR *= ENC_R_DIR;
//        total_L += dL;    total_R += dR;
//        prev_L = curr_L;  prev_R = curr_R;
//
//        int32_t avg_pos = (total_L + total_R) / 2;
//        if (avg_pos < 0) avg_pos = 0;
//
//        // Stall watchdog
//        uint32_t now = osKernelGetTickCount();
//        if (avg_pos > last_avg + 3) { last_avg = avg_pos; last_prog = now; }
//        else if ((now - last_prog) > STALL_MS) {
//            UART_Sendf("STALL detected — HARD STOP\r\n");
//            Drive_brake();
//            SetServoPosition(SERVO_CENTER_US + STATIC_STRAIGHT_OFFSET_US);
//            return;
//        }
//
//        // ----- Wheel-sync PWM split -----
//        int32_t err = (total_L - total_R);
//        err_int += err;
//        if (err_int >  I_WSYNC_LIM) err_int =  I_WSYNC_LIM;
//        if (err_int < -I_WSYNC_LIM) err_int = -I_WSYNC_LIM;
//
//        int32_t corr = (int32_t)(KP_WSYNC * err + KI_WSYNC * err_int);
//        if (corr >  CORR_LIM) corr =  CORR_LIM;
//        if (corr < -CORR_LIM) corr = -CORR_LIM;
//
//        int16_t left_pwm  = (int16_t)duty - (int16_t)corr;
//        int16_t right_pwm = (int16_t)duty + (int16_t)corr;
//
//        uint16_t pwm_floor = (uint16_t)(htim8.Init.Period * 0.12f);
//        if (left_pwm  < (int16_t)pwm_floor)  left_pwm  = (int16_t)pwm_floor;
//        if (right_pwm < (int16_t)pwm_floor)  right_pwm = (int16_t)pwm_floor;
//
//        Drive_set(left_pwm, right_pwm);
//
//        // ----- Servo heading correction -----
//        float yaw_err = turn_angle - yaw_start;
//        if (yaw_err > 180.0f)  yaw_err -= 360.0f;
//        if (yaw_err < -180.0f) yaw_err += 360.0f;
//
//        float cmd_err = 0.0f;
//        if (yaw_err >  (YAW_THRESH_DEG))          cmd_err = yaw_err - YAW_HYST_DEG;
//        else if (yaw_err < -(YAW_THRESH_DEG))     cmd_err = yaw_err + YAW_HYST_DEG;
//
//        int target_trim = (int)lroundf(cmd_err * TRIM_GAIN_US_PER_DEG);
//        if (target_trim >  TRIM_MAX_US) target_trim =  TRIM_MAX_US;
//        if (target_trim < -TRIM_MAX_US) target_trim = -TRIM_MAX_US;
//
//        int step = target_trim - trim_us;
//        if (step >  TRIM_SLEW_US) step =  TRIM_SLEW_US;
//        if (step < -TRIM_SLEW_US) step = -TRIM_SLEW_US;
//        trim_us += step;
//        SetServoPosition(SERVO_CENTER_US + STATIC_STRAIGHT_OFFSET_US + trim_us);
//
//        // ----- Reached target distance -----
//        if (avg_pos >= target_ticks) {
//            Drive_brake();                          // HARD stop
//            SetServoPosition(SERVO_CENTER_US + STATIC_STRAIGHT_OFFSET_US);
//            UART_Sendf("Reached %.1f cm — HARD STOP\r\n", distance_cm);
//            return;
//        }
//    }
//}
//


//WITH DISTANCE SNAPSHOT
void MoveForwardDistance_us(uint16_t duty, float distance_cm)
{
    if (distance_cm <= 0.0f || duty == 0) return;

    const uint32_t LOOP_DT_MS = 5;                 // 200 Hz
    const int32_t  target_ticks = (int32_t)(distance_cm * TICKS_PER_CM + 0.5f);

    // ===== Servo correction =====
    const float  YAW_THRESH_DEG   = 1.0f;
    const float  YAW_HYST_DEG     = 0.5f;
    const int    SERVO_CENTER_US  = SERVO_STRAIGHT;
    const int    TRIM_MAX_US      = 150;
    const int    TRIM_SLEW_US     = 6;
    const float  TRIM_GAIN_US_PER_DEG = 18.0f;
    const int    STATIC_STRAIGHT_OFFSET_US = 0;

    // ===== Wheel-sync (encoder) =====
    const float   KP_WSYNC   = 0.12f;
    const float   KI_WSYNC   = 0.0020f;
    const int16_t I_WSYNC_LIM = 400;
    const int16_t CORR_LIM     = 600;
    int32_t err_int = 0;

    // ===== Ultrasonic safety =====
    const float   STOP_CM = 25.0f;
    const float   SAFETY_MARGIN_CM = 10.0f;
    const uint8_t CLOSE_THRESHOLD   = 1;

    // ===== Stall protection =====
    const uint32_t STALL_MS = 800;

    // ===== Setup =====
    Drive_set(0,0); osDelay(5);
    SetServoPosition(SERVO_CENTER_US + STATIC_STRAIGHT_OFFSET_US);
    osDelay(10);

    // Encoders
    __HAL_TIM_SET_COUNTER(&htim2, 0);
    __HAL_TIM_SET_COUNTER(&htim3, 0);
    HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_ALL);
    HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_ALL);

    uint16_t prev_L = (uint16_t)__HAL_TIM_GET_COUNTER(&htim2);
    uint16_t prev_R = (uint16_t)__HAL_TIM_GET_COUNTER(&htim3);
    int32_t  total_L = 0, total_R = 0;

    float    yaw_start = turn_angle;
    int      trim_us   = 0;
    uint8_t  close_count = 0;

    int32_t  last_avg  = 0;
    uint32_t last_prog = osKernelGetTickCount();
    int32_t  avg_pos   = 0;          // FIX: single definition only

    // Start driving
    Drive_set(duty, duty);

    while (1)
    {
        osDelay(LOOP_DT_MS);

        // ===== 1) ENCODER UPDATES FIRST (so avg_pos is fresh) =====
        uint16_t curr_L = (uint16_t)__HAL_TIM_GET_COUNTER(&htim2);
        uint16_t curr_R = (uint16_t)__HAL_TIM_GET_COUNTER(&htim3);
        int32_t dL = (int32_t)(curr_L - prev_L);
        int32_t dR = (int32_t)(curr_R - prev_R);
        if (dL >  32767) dL -= 65536;  if (dL < -32768) dL += 65536;
        if (dR >  32767) dR -= 65536;  if (dR < -32768) dR += 65536;
        dL *= ENC_L_DIR;  dR *= ENC_R_DIR;
        total_L += dL;    total_R += dR;
        prev_L = curr_L;  prev_R = curr_R;

        avg_pos = (total_L + total_R) / 2;         // FIX: assign, don't redeclare
        if (avg_pos < 0) avg_pos = 0;

        // ===== 2) STALL WATCHDOG =====
        uint32_t now = osKernelGetTickCount();
        if (avg_pos > last_avg + 3) { last_avg = avg_pos; last_prog = now; }
        else if ((now - last_prog) > STALL_MS) {
            UART_Sendf("STALL detected — HARD STOP\r\n");
            Drive_brake();
            SetServoPosition(SERVO_CENTER_US + STATIC_STRAIGHT_OFFSET_US);
            g_total_encoder_ticks += avg_pos;      // FIX: accumulate on stall exit
            return;
        }

        // ===== 3) ULTRASONIC SAFETY (uses fresh avg_pos) =====
        float current_dist; uint8_t dist_valid;
        uint32_t primask = __get_PRIMASK();
        __disable_irq();
        current_dist = g_latest_dist_cm;
        dist_valid   = g_us_valid && ((HAL_GetTick() - g_us_ts_ms) <= US_FRESH_MS);
        __set_PRIMASK(primask);

        if (dist_valid && current_dist <= (STOP_CM + SAFETY_MARGIN_CM)) {
            if (++close_count >= CLOSE_THRESHOLD) {
                Drive_brake();                          // HARD stop immediately
                SetServoPosition(SERVO_CENTER_US + STATIC_STRAIGHT_OFFSET_US);
                UART_Sendf("US stop triggered at %.1f cm — HARD STOP\r\n", current_dist);

                g_total_encoder_ticks += avg_pos;

                        if (!g_first_obstacle_saved) {
                            g_ticks_at_first_obstacle        = g_total_encoder_ticks;
                            g_front_gap_at_first_obstacle_cm = current_dist;
                            g_first_obstacle_saved           = 1;
                            UART_Sendf("SNAP#1: ticks=%ld, front_gap=%.1f\r\n",
                                       (long)g_ticks_at_first_obstacle,
                                       g_front_gap_at_first_obstacle_cm);
                        } else if (!g_second_obstacle_saved) {
                            g_ticks_at_second_obstacle        = g_total_encoder_ticks;
                            g_front_gap_at_second_obstacle_cm = current_dist;
                            g_second_obstacle_saved           = 1;
                            UART_Sendf("SNAP#2: ticks=%ld, front_gap=%.1f\r\n",
                                       (long)g_ticks_at_second_obstacle,
                                       g_front_gap_at_second_obstacle_cm);
                        } else {
                            UART_Sendf("SNAP: already have 2 snapshots\r\n");
                        }
                        return;                            // exit instantly
            }
        } else {
            close_count = 0;
        }

        // ===== 4) WHEEL-SYNC PWM SPLIT =====
        int32_t err = (total_L - total_R);
        err_int += err;
        if (err_int >  I_WSYNC_LIM) err_int =  I_WSYNC_LIM;
        if (err_int < -I_WSYNC_LIM) err_int = -I_WSYNC_LIM;

        int32_t corr = (int32_t)(KP_WSYNC * err + KI_WSYNC * err_int);
        if (corr >  CORR_LIM) corr =  CORR_LIM;
        if (corr < -CORR_LIM) corr = -CORR_LIM;

        int16_t left_pwm  = (int16_t)duty - (int16_t)corr;
        int16_t right_pwm = (int16_t)duty + (int16_t)corr;

        uint16_t pwm_floor = (uint16_t)(htim8.Init.Period * 0.12f);
        if (left_pwm  < (int16_t)pwm_floor)  left_pwm  = (int16_t)pwm_floor;
        if (right_pwm < (int16_t)pwm_floor)  right_pwm = (int16_t)pwm_floor;

        Drive_set(left_pwm, right_pwm);

        // ===== 5) SERVO HEADING CORRECTION =====
        float yaw_err = turn_angle - yaw_start;
        if (yaw_err > 180.0f)  yaw_err -= 360.0f;
        if (yaw_err < -180.0f) yaw_err += 360.0f;

        float cmd_err = 0.0f;
        if (yaw_err >  (YAW_THRESH_DEG))          cmd_err = yaw_err - YAW_HYST_DEG;
        else if (yaw_err < -(YAW_THRESH_DEG))     cmd_err = yaw_err + YAW_HYST_DEG;

        int target_trim = (int)lroundf(cmd_err * TRIM_GAIN_US_PER_DEG);
        if (target_trim >  TRIM_MAX_US) target_trim =  TRIM_MAX_US;
        if (target_trim < -TRIM_MAX_US) target_trim = -TRIM_MAX_US;

        int step = target_trim - trim_us;
        if (step >  TRIM_SLEW_US) step =  TRIM_SLEW_US;
        if (step < -TRIM_SLEW_US) step = -TRIM_SLEW_US;
        trim_us += step;
        SetServoPosition(SERVO_CENTER_US + STATIC_STRAIGHT_OFFSET_US + trim_us);

        // ===== 6) REACHED TARGET DISTANCE =====
        if (avg_pos >= target_ticks) {
            Drive_brake();                          // HARD stop
            SetServoPosition(SERVO_CENTER_US + STATIC_STRAIGHT_OFFSET_US);
            UART_Sendf("Reached %.1f cm — HARD STOP\r\n", distance_cm);
            g_total_encoder_ticks += avg_pos;       // FIX: accumulate on normal finish
            return;
        }
    }
}


void MoveForwardDistance_us_shorter(uint16_t duty, float distance_cm)
{
    if (distance_cm <= 0.0f || duty == 0) return;

    const uint32_t LOOP_DT_MS = 5;
    const float    DT         = 0.005f;
    const int32_t target_ticks = (int32_t)(distance_cm * TICKS_PER_CM + 0.5f);

    // Heading PID
    const int    YAW_SIGN        = +1;
    const float  YAW_KP          = 20.0f;
    const float  YAW_KI          =  1.0f;
    const float  YAW_KD          =  5.0f;
    const float  YAW_DEAD        =  0.15f;
    const int    SERVO_CENTER_US = SERVO_STRAIGHT;
    const int    SERVO_OUT_MAX   = 200;
    const int    SERVO_SLEW_US   = 5;

    float yaw_start   = turn_angle;
    float yaw_i       = 0.0f;
    float prev_yaw_e  = 0.0f;
    int   servo_trim  = 0;

    // Setup
    Drive_set(0, 0);
    osDelay(5);
    SetServoPosition(SERVO_CENTER_US);
    osDelay(10);

    // Encoder reset
    __HAL_TIM_SET_COUNTER(&htim2, 0);
    __HAL_TIM_SET_COUNTER(&htim3, 0);
    HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_ALL);
    HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_ALL);

    uint16_t prev_L = (uint16_t)__HAL_TIM_GET_COUNTER(&htim2);
    uint16_t prev_R = (uint16_t)__HAL_TIM_GET_COUNTER(&htim3);
    int32_t  total_L = 0, total_R = 0;

    Drive_set(duty, duty);

    int32_t   last_avg = 0;
    uint32_t  last_prog = osKernelGetTickCount();
    const uint32_t STALL_MS = 800;

    // *** CRITICAL: Stopping distance with safety margin ***
    const float STOP_CM = 10.0f;
    const float SAFETY_MARGIN_CM = 10.0f;  // Extra 10cm for reaction time

    // Consecutive close reading filter (reduces false stops)
    uint8_t close_count = 0;
    const uint8_t CLOSE_THRESHOLD = 2;  // Must see obstacle 2 times

    while (1) {
        // ===== CHECK ULTRASONIC FIRST (CRITICAL FOR SAFETY) =====
        float current_dist;
        uint8_t dist_valid;

        uint32_t primask = __get_PRIMASK();  // save interrupt state
        __disable_irq();
        current_dist = g_latest_dist_cm;
        dist_valid = g_us_valid && ((HAL_GetTick() - g_us_ts_ms) <= US_FRESH_MS);
        __set_PRIMASK(primask);  // restore interrupt state exactly as before

        // Obstacle detection with hysteresis
        if (dist_valid && (current_dist <= (STOP_CM + SAFETY_MARGIN_CM))) {
            close_count++;
            if (close_count >= CLOSE_THRESHOLD) {
                // EMERGENCY STOP!
                Drive_brake();
                osDelay(30);
                Drive_set(0, 0);
                SetServoPosition(SERVO_CENTER_US);
                return;  // Exit immediately
            }
        } else {
            close_count = 0;  // Reset if obstacle moves away
        }

        osDelay(LOOP_DT_MS);

        // ===== ENCODER TRACKING =====
        uint16_t curr_L = (uint16_t)__HAL_TIM_GET_COUNTER(&htim2);
        uint16_t curr_R = (uint16_t)__HAL_TIM_GET_COUNTER(&htim3);

        int32_t dL = (int32_t)(curr_L - prev_L);
        int32_t dR = (int32_t)(curr_R - prev_R);
        if (dL >  32767) dL -= 65536;  if (dL < -32768) dL += 65536;
        if (dR >  32767) dR -= 65536;  if (dR < -32768) dR += 65536;

        dL *= ENC_L_DIR;
        dR *= ENC_R_DIR;

        total_L += dL;
        total_R += dR;
        prev_L = curr_L;
        prev_R = curr_R;

        int32_t avg_pos = (total_L + total_R) / 2;
        if (avg_pos < 0) avg_pos = 0;

        // Watchdog
        uint32_t now = osKernelGetTickCount();
        if (avg_pos > last_avg + 3) { last_avg = avg_pos; last_prog = now; }
        else if ((now - last_prog) > STALL_MS) break;

        // ===== HEADING PID =====
        float yaw_err = turn_angle - yaw_start;
        if (fabsf(yaw_err) < YAW_DEAD) yaw_err = 0.0f;

        yaw_i += yaw_err * DT;
        if (yaw_i >  5.0f) yaw_i =  5.0f;
        if (yaw_i < -5.0f) yaw_i = -5.0f;

        float dyaw = (yaw_err - prev_yaw_e) / DT;
        prev_yaw_e = yaw_err;

        float u      = (YAW_KP * yaw_err) + (YAW_KI * yaw_i) + (YAW_KD * dyaw);
        int   u_us   = (int)lroundf((float)YAW_SIGN * u);

        if (u_us >  SERVO_OUT_MAX) u_us =  SERVO_OUT_MAX;
        if (u_us < -SERVO_OUT_MAX) u_us = -SERVO_OUT_MAX;

        int step = u_us - servo_trim;
        if (step >  SERVO_SLEW_US) step =  SERVO_SLEW_US;
        if (step < -SERVO_SLEW_US) step = -SERVO_SLEW_US;
        servo_trim += step;

        SetServoPosition(SERVO_CENTER_US + servo_trim);

        // Target reached normally
        if (avg_pos >= target_ticks) break;
    }

    // Normal stop
    Drive_brake();
    SetServoPosition(SERVO_CENTER_US);
    osDelay(10);
}

// --- add once near your other helpers ---
static inline int16_t clamp_s16(int32_t v, int16_t lo, int16_t hi){
    return (v < lo) ? lo : (v > hi) ? hi : (int16_t)v;
}

void MoveBackwardDistance(uint16_t duty, float distance_cm)
{
    if (distance_cm <= 0.0f || duty == 0) return;

    // === loop timing ===
    const uint32_t LOOP_DT_MS = 5;

    // === target ticks (we count reverse as positive progress) ===
    const int32_t target_ticks = (int32_t)(distance_cm * TICKS_PER_CM + 0.5f);

    // === encoders reset/start ===
    __HAL_TIM_SET_COUNTER(&htim2, 0);
    __HAL_TIM_SET_COUNTER(&htim3, 0);
    HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_ALL);
    HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_ALL);

    uint16_t last_L = (uint16_t)__HAL_TIM_GET_COUNTER(&htim2);
    uint16_t last_R = (uint16_t)__HAL_TIM_GET_COUNTER(&htim3);
    int32_t  totL   = 0, totR   = 0;

    // center the wheels and run both motors in reverse at fixed duty
    SetServoPosition(SERVO_STRAIGHT);
    osDelay(10);
    const int16_t base = -(int16_t)duty;   // reverse = negative
    Drive_set(base, base);

    // optional: progress watchdog so the task can’t hang forever
    int32_t   last_avg  = 0;
    uint32_t  last_prog = osKernelGetTickCount();
    const uint32_t STALL_MS = 800;

    while (1) {
        osDelay(LOOP_DT_MS);

        // --- read encoders (wrap-safe) ---
        uint16_t nowL = (uint16_t)__HAL_TIM_GET_COUNTER(&htim2);
        uint16_t nowR = (uint16_t)__HAL_TIM_GET_COUNTER(&htim3);
        int32_t dL = (int32_t)(nowL - last_L);
        int32_t dR = (int32_t)(nowR - last_R);
        if (dL >  32767) dL -= 65536;  if (dL < -32768) dL += 65536;
        if (dR >  32767) dR -= 65536;  if (dR < -32768) dR += 65536;

        // make forward-positive; we are moving reverse, so negate for progress
        dL *= ENC_L_DIR;  dR *= ENC_R_DIR;
        totL += -dL;      totR += -dR;

        last_L = nowL;    last_R = nowR;

        // --- tiny wheel-sync to keep tracks even (no servo here) ---
        int32_t err   = totL - totR;                 // + means left “more reverse ?
        int32_t corr  = err / 2;                      // small proportional
        int16_t cmdL  = base + (int16_t)corr;         // move toward 0 (less negative) if ahead
        int16_t cmdR  = base - (int16_t)corr;

        // never allow a wheel to go forward
        if (cmdL > 0) cmdL = 0;
        if (cmdR > 0) cmdR = 0;

        Drive_set(cmdL, cmdR);

        // --- done / watchdog ---
        int32_t avg = (totL + totR) / 2;
        uint32_t now = osKernelGetTickCount();
        if (avg > last_avg + 3) { last_avg = avg; last_prog = now; }
        else if ((now - last_prog) > STALL_MS) break;

        if (avg >= target_ticks) break;
    }

    // simple stop (avoid active brake to prevent OLED brownout)
    Drive_brake();
    SetServoPosition(SERVO_STRAIGHT);
    osDelay(10);
}

// UART
void UART_Sendf(const char *fmt, ...)
{
    char buf[128];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    if (n < 0) return;
    if (n > (int)sizeof(buf)) n = sizeof(buf);
    HAL_UART_Transmit(&huart3, (uint8_t*)buf, (uint16_t)n, 100);
}
//static inline void UART_Prompt(void) {
//    // \r = carriage return; \x1b[2K = clear entire line
//    UART_Sendf("\r\x1b[2K ");
//}
//
static inline void UART_SendAck(char cmd) {
    UART_Sendf("ACK,%c\n", cmd);
    //UART_Prompt();
}

static inline void UART_SendUReport(char cmd_tag)
{
    float dist_cm; uint8_t valid; uint32_t age_ms;
    __disable_irq();
    dist_cm = g_latest_dist_cm;
    valid   = g_us_valid;
    age_ms  = HAL_GetTick() - g_us_ts_ms;
    __enable_irq();

    float angle_deg = turn_angle;

    // compact CSV-ish line; easy to parse on the Pi
    UART_Sendf("DONE,%c,dist_cm=%.1f,angle_deg=%.1f,valid=%u,age_ms=%lu\n",
               cmd_tag, dist_cm, angle_deg, (unsigned)valid, (unsigned long)age_ms);
}


void UARTTask(void *argument) {
    char cmd[CMD_BUF_SIZE];

    for (;;) {
        if (osMessageQueueGet(uartQueue, cmd, NULL, osWaitForever) == osOK) {
            // Forward to motor queue
            osMessageQueuePut(motorQueue, cmd, 0, 0);
        }
    }
}




void StartMotorTask(void *argument) {
    char cmd[CMD_BUF_SIZE];
    const uint16_t duty_normal     = (uint16_t)(htim8.Init.Period * 30 / 100);  // ~30%
    const uint16_t duty_turn_rev   = (uint16_t)(htim8.Init.Period * 30 / 100);  // a bit gentler for reverse turns

    for (;;) {
        if (osMessageQueueGet(motorQueue, cmd, NULL, osWaitForever) == osOK) {
            char action = cmd[0];
            int value   = atoi(&cmd[1]);   // angle or distance depending on action

            switch (action) {
                case 'F':  // forward distance (cm)
                    MoveForwardDistance(duty_normal, value);
                    UART_SendUReport('F');
                    break;

                case 'B':  // backward distance (cm)
                    MoveBackwardDistance(duty_normal, value);
                    UART_SendUReport('B');
                    break;

                case 'L':  // forward turn left by +angle
                    TurnForward(value, duty_normal);
                    UART_SendUReport('L');
                    break;

                case 'R':  // forward turn right by -angle
                    TurnForward(-value, duty_normal);
                    UART_SendUReport('R');
                    break;

                case 'l':  // REVERSE turn: left yaw while backing up
                    TurnBackward(+value, duty_turn_rev);
                    break;

                case 'r':  // REVERSE turn: right yaw while backing up
                    TurnBackward(-value, duty_turn_rev);
                    break;

                case 'U':  // forward distance (cm) - ultrasonic

                	MoveForwardDistance_us(duty_normal, value);
                	osDelay(300);
                	UART_SendAck('U');
                	UART_SendUReport('U');
                	break;

                case 'V':  // forward distance (cm) - ultrasonic shorter
                     MoveForwardDistance_us_shorter(duty_normal, value);
                     break;

                case 'S':  // stop / brake
                    Drive_brake();
                    break;

                default:
                    OLED_Clear();
                    OLED_ShowString(0, 0, (uint8_t*)"Unknown cmd");
                    OLED_Refresh_Gram();
                    break;
            }
        }
    }
}

//SERVO
void SetServoPosition(int pwmValue) {
	__HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_2, pwmValue);
}

void UART_TestEcho(void)
{
    uint8_t ch;
    char buffer[RX_BUF_SIZE];
    uint8_t idx = 0;

    while (1)
    {
        // blocking receive, waits for a character
        if (HAL_UART_Receive(&huart3, &ch, 1, HAL_MAX_DELAY) == HAL_OK) {

            if (ch != '\n' && ch != '\r' && idx < RX_BUF_SIZE - 1) {
                buffer[idx++] = ch;
            }
            else {
                // terminate string
                buffer[idx] = '\0';
                idx = 0;

                // display on OLED
                OLED_Clear();
                OLED_ShowString(0, 0, (uint8_t*)buffer);
                OLED_Refresh_Gram();
            }
        }
    }
}


static inline int ServoFromDeg(float cmd_deg)
{
    float mag = fabsf(cmd_deg) / 90.0f;

    // asymmetry tuning — smoother left response
    const float LEFT_GAIN   = 2.8f;   // ↓ from 3.2 → smoother, less tight
    const float RIGHT_GAIN  = 4.0f;   // unchanged (still crisp)
    const float GAMMA_L     = 0.60f;  // ↑ from 0.55 → more linear left curve
    const float GAMMA_R     = 0.45f;  // unchanged
    const float OVERSHOOT_L = 1.10f;  // ↓ from 1.20 → limits left servo swing
    const float OVERSHOOT_R = 1.35f;  // unchanged

    if (cmd_deg < 0) {  // RIGHT turn (CW)
        mag *= RIGHT_GAIN;
        mag = powf(mag, GAMMA_R);
        if (mag > OVERSHOOT_R) mag = OVERSHOOT_R;

        int pwm = SERVO_STRAIGHT + (int)((SERVO_RIGHT - SERVO_STRAIGHT) * mag);
        if (pwm > SERVO_RIGHT + 120) pwm = SERVO_RIGHT + 120;
        return pwm;

    } else {  // LEFT turn (CCW)
        mag *= LEFT_GAIN;
        mag = powf(mag, GAMMA_L);
        if (mag > OVERSHOOT_L) mag = OVERSHOOT_L;

        int pwm = SERVO_STRAIGHT - (int)((SERVO_STRAIGHT - SERVO_LEFT) * mag);
        if (pwm < SERVO_LEFT - 120) pwm = SERVO_LEFT - 120;
        return pwm;
    }
}



// Map command ±90° to PHYSICAL wheel steer ±MAX_STEER_DEG with left/right scale
static inline float SteerDegFromCommand(float cmd_deg){
    float frac  = fminf(fabsf(cmd_deg), 90.0f) / 90.0f;
    float scale = (cmd_deg >= 0.0f) ? LEFT_STEER_SCALE : RIGHT_STEER_SCALE;
    float s     = frac * MAX_STEER_DEG * scale;
    if (s >  MAX_STEER_DEG) s =  MAX_STEER_DEG;
    if (s < -MAX_STEER_DEG) s = -MAX_STEER_DEG;
    return (cmd_deg >= 0.0f) ? s : -s;
}

// Geometry split with strong right-turn asymmetry
static inline void speedSplitFromSteer(float steer_deg, uint16_t base_pwm, int16_t *outL, int16_t *outR)
{
    const float INNER_MIN_FRAC = 0.18f;  // keep torque on inner wheel
    const float OUTER_MIN_FRAC = 0.28f;  // and on outer

    float delta = steer_deg * (PI_F / 180.0f);
    if (fabsf(delta) < 1e-3f) { *outL = base_pwm; *outR = base_pwm; return; }

    float R  = WHEELBASE_CM / tanf(delta);
    float Ri = fabsf(R) - TRACK_CM * 0.5f;
    float Ro = fabsf(R) + TRACK_CM * 0.5f;
    if (Ri < 1.0f) Ri = 1.0f;

    float ratio = Ri / Ro;                      // inner/outer speed ratio (0..1)

    // Direction-specific gains (RIGHT turns need more tightening)
    float inner_gain  = (delta < 0.0f) ? RIGHT_INNER_GAIN  : LEFT_INNER_GAIN;
    float outer_boost = (delta < 0.0f) ? RIGHT_OUTER_BOOST : LEFT_OUTER_BOOST;

    ratio /= inner_gain;
    if (ratio < 0.05f) ratio = 0.05f;
    if (ratio > 1.00f) ratio = 1.00f;

    float outer_f = (float)base_pwm * outer_boost;
    float inner_f = (float)base_pwm * ratio;

    float inner_floor = (float)base_pwm * INNER_MIN_FRAC;
    float outer_floor = (float)base_pwm * OUTER_MIN_FRAC;
    if (inner_f < inner_floor) inner_f = inner_floor;
    if (outer_f < outer_floor) outer_f = outer_floor;

    uint32_t PWM_MAX = htim8.Init.Period;
    if (inner_f > (float)PWM_MAX) inner_f = (float)PWM_MAX;
    if (outer_f > (float)PWM_MAX) outer_f = (float)PWM_MAX;

    uint16_t inner = (uint16_t)(inner_f + 0.5f);
    uint16_t outer = (uint16_t)(outer_f + 0.5f);

    // left steer: left=inner, right=outer ; right steer: opposite
    if (delta > 0.0f) { *outL = inner; *outR = outer; }   // LEFT
    else              { *outL = outer; *outR = inner; }   // RIGHT
}

void TurnForward(int angle_deg, uint16_t duty)  // + = left (CCW), - = right (CW)
{
    // === Empirical offsets (your existing tweak) ===
    if (angle_deg > 0) {
        switch (abs(angle_deg)) {
            case 45:  angle_deg -= 12;  break;
            case 90:  angle_deg -= 12; break;
            case 135: angle_deg -= 13; break;
            case 180: angle_deg -= 13; break;
            default: break;
        }
    } else if (angle_deg < 0) {
        switch (abs(angle_deg)) {
            case 45:  angle_deg += 7;  break;
            case 90:  angle_deg += 9; break;
            case 135: angle_deg += 13; break;
            case 180: angle_deg += 14; break;
            default: break;
        }
    }

    // === Setup steering ===
    int servo_cmd = ServoFromDeg((float)angle_deg);
    SetServoPosition(servo_cmd);
    osDelay(200);

    float start  = turn_angle;
    float target = start + (float)angle_deg;
    float absA   = fabsf((float)angle_deg);
    if (absA < 1.0f) { Drive_set(0,0); SetServoPosition(SERVO_STRAIGHT); return; }

    // === Params ===
    const uint16_t MIN_PWM   = (uint16_t)(duty * 0.65f);
    const float    FIXED_LEAD_DEG = 0.6f;    // constant lead
    const float    BRAKE_TIME_S   = 0.030f;  // estimated stop latency

    // keep full steer engaged; no early straightening
    float steer_deg = SteerDegFromCommand((float)angle_deg);

    // yaw-rate timing
    uint32_t prev_ms = HAL_GetTick();
    float    prev_yaw = turn_angle;

    while (1) {
        uint32_t now_ms = HAL_GetTick();
        float dt = (now_ms - prev_ms) * 0.001f;     // seconds
        if (dt <= 0.0f) dt = 0.001f;                // guard
        prev_ms = now_ms;

        float yaw = turn_angle;
        float rem = target - yaw;

        // ramp duty but hold steer
        float progress = fminf(fabsf((yaw - start)) / absA, 1.0f);
        uint16_t duty_now = (uint16_t)(MIN_PWM + (1.0f - progress) * (duty - MIN_PWM));
        if (duty_now < MIN_PWM) duty_now = MIN_PWM;

        int16_t l_pwm, r_pwm;
        speedSplitFromSteer(steer_deg, duty_now, &l_pwm, &r_pwm);
        Drive_set(l_pwm, r_pwm);

        // dynamic brake lead
        float yaw_rate = (yaw - prev_yaw) / dt;     // deg/s
        prev_yaw = yaw;
        float brake_lead = FIXED_LEAD_DEG + fabsf(yaw_rate) * BRAKE_TIME_S;
        if (brake_lead > 5.0f) brake_lead = 5.0f;   // clamp sane

        bool do_brake = false;
        if (angle_deg > 0) {        // CCW (left)
            if (yaw >= (target - brake_lead)) do_brake = true;
        } else {                    // CW (right)
            if (yaw <= (target + brake_lead)) do_brake = true;
        }

        if (do_brake) {
            Drive_brake();
            osDelay(8);                     // short, crisp
            SetServoPosition(SERVO_STRAIGHT);
            Drive_set(0,0);
            return;
        }

        osDelay(5);
    }
}


void TurnBackward(int angle_deg, uint16_t duty)  // + = left yaw, - = right yaw (while reversing)
{
    // same bias tweak as forward (optional)
    if (angle_deg > 0) angle_deg -= 10;
    else if (angle_deg < 0) angle_deg += 10;

    uint16_t pwm_abs_floor = (uint16_t)(htim8.Init.Period * MIN_TURN_PWM_ABS_FRAC);
    uint16_t MIN_TURN_PWM  = (uint16_t)(duty * 0.65f);
    if (MIN_TURN_PWM < pwm_abs_floor) MIN_TURN_PWM = pwm_abs_floor;

    const float STRAIGHTEN_PROGRESS = 0.995f;
    const float BRAKE_LEAD_DEG      = 0.20f;

    // reverse steering to get same yaw sign while backing up
    SetServoPosition(ServoFromDeg((float)(-angle_deg)));
    osDelay(200);

    float start  = turn_angle;
    float target = start + (float)angle_deg;
    float absA   = fabsf((float)angle_deg);
    if (absA < 1.0f) { Drive_set(0,0); SetServoPosition(SERVO_STRAIGHT); return; }

    float steer_deg = SteerDegFromCommand((float)(-angle_deg)); // invert for reverse

    while (1) {
        float yaw = turn_angle;
        float rem = target - yaw;

        float progress = fminf(fabsf((yaw - start)) / absA, 1.0f);
        if (progress >= STRAIGHTEN_PROGRESS)
            SetServoPosition(SERVO_STRAIGHT);

        float ramp = fminf(fabsf(rem) / absA, 1.0f);
        uint16_t duty_now = (uint16_t)(MIN_TURN_PWM + ramp * (duty - MIN_TURN_PWM));
        if (duty_now < MIN_TURN_PWM) duty_now = MIN_TURN_PWM;

        // compute forward split then flip signs for reverse (never positive)
        int16_t fL, fR;  speedSplitFromSteer(steer_deg, duty_now, &fL, &fR);
        int16_t l = -fL; if (l > 0) l = 0;
        int16_t r = -fR; if (r > 0) r = 0;
        Drive_set(l, r);

        if (((angle_deg > 0) && (rem <= BRAKE_LEAD_DEG)) ||
            ((angle_deg < 0) && (rem >= -BRAKE_LEAD_DEG)) ||
            ((angle_deg > 0) && (yaw >= target)) ||
            ((angle_deg < 0) && (yaw <= target))) {

            Drive_brake(); osDelay(30);
            Drive_set(0,0);
            SetServoPosition(SERVO_STRAIGHT);
            break;
        }
        osDelay(5);
    }
}





void StartServoTask(void *argument){
	const uint16_t duty_normal = (uint16_t)(htim8.Init.Period * 30 / 100);  // ~30%

	//TurnForward(90,duty_normal);
	//osDelay(1000);
//	TurnForward(90,duty_normal);
//	osDelay(1000);
TurnForward(360,duty_normal);
osDelay(1000);
//	TurnForward(270,duty_normal);
//	osDelay(1000);
//	TurnForward(360,duty_normal);

//	TurnForward(-45,duty_normal);
//	osDelay(1000);
//	TurnForward(-90,duty_normal);
//	osDelay(1000);
//	TurnForward(-180,duty_normal);
//	osDelay(1000);
//	TurnForward(-270,duty_normal);
//	osDelay(1000);
//	TurnForward(-360,duty_normal);

//	SetServoPosition(SERVO_LEFT);
//	osDelay(1000);
//
//	SetServoPosition(SERVO_STRAIGHT);
//	osDelay(1000);
//
//	SetServoPosition(SERVO_RIGHT);
//	osDelay(1000);
//
//	// back to straight
//	SetServoPosition(SERVO_STRAIGHT);
//	osDelay(1000);
}

//ULTRASONIC
//ULTRASONIC
void delay_us(uint16_t us) {
    __HAL_TIM_SET_COUNTER(&htim6, 0);
    while (__HAL_TIM_GET_COUNTER(&htim6) < us);
}

// ISR
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM12 && htim->Channel == HAL_TIM_ACTIVE_CHANNEL_2)
    {
        isr_count++;

        if (is_rising) {
            tc1 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_2);
            is_rising = 0;
            __HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_2, TIM_INPUTCHANNELPOLARITY_FALLING);
        } else {
            tc2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_2);
            is_rising = 1;
            __HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_2, TIM_INPUTCHANNELPOLARITY_RISING);

            if (tc2 >= tc1) echo = tc2 - tc1;
            else            echo = (0xFFFF - tc1) + tc2;

            echo_ready = 1;
        }
    }
}

// Trigger pulse
static inline void HCSR04_Trig(void) {
    HAL_GPIO_WritePin(Ultrasonic_Trig_GPIO_Port, Ultrasonic_Trig_Pin, GPIO_PIN_RESET);
    delay_us(2);
    HAL_GPIO_WritePin(Ultrasonic_Trig_GPIO_Port, Ultrasonic_Trig_Pin, GPIO_PIN_SET);
    delay_us(10);
    HAL_GPIO_WritePin(Ultrasonic_Trig_GPIO_Port, Ultrasonic_Trig_Pin, GPIO_PIN_RESET);
}

/* ==========================================================
   Command Handler Task
   ========================================================== */

// === HELPER: Turn until ultrasonic detects open space ===
void TurnUntilOpen(float open_cm, int direction, uint16_t duty)
{
    // direction: +1 = left, -1 = right
    const int TURN_DEG = 20;          // per probe
    const float FWD_DIST_CM = 10.0f;  // forward per probe
    const float BACK_DIST_CM = 5.0f;
    const float IR_GAP_CM = 12.0f;    // threshold for gap trigger
    const uint32_t PAUSE_MS = 150;

    UART_Sendf("TurnUntilOpen: searching for gap >= %.1f cm (%s)\r\n",
               open_cm, (direction > 0) ? "left" : "right");
    osDelay(2);

    while (1)
    {
        // === Step 1: Turn slightly & move forward ===
        UART_Sendf("Turning %s %d° and probing forward...\r\n",
                   (direction > 0) ? "left" : "right", TURN_DEG);
        TurnForward(direction * TURN_DEG, duty);
        MoveForwardDistance_us(duty, FWD_DIST_CM);
        Drive_brake();
        osDelay(10);

        // === Step 2: Read sensors ===
        float us_dist, ir_dist;
        uint8_t valid_us;
        taskENTER_CRITICAL();
        us_dist = g_latest_dist_cm;
        valid_us = g_us_valid && ((HAL_GetTick() - g_us_ts_ms) <= US_FRESH_MS);
        taskEXIT_CRITICAL();

        // pick side IR based on direction
        if (direction > 0)
            ir_dist = IR1_GetDistanceCm();   // left IR
        else
            ir_dist = IR2_GetDistanceCm();   // right IR

        UART_Sendf("US=%.1f cm | IR=%.1f cm\r\n", us_dist, ir_dist);

        // === Step 3: Decision logic ===
        if ((valid_us && us_dist > open_cm) ||          // front open
            (ir_dist > 0 && ir_dist <= IR_GAP_CM))      // side close/open
        {
            UART_Sendf("Open gap detected — stopping.\r\n");
            Drive_brake();
            SetServoPosition(SERVO_STRAIGHT);
            osDelay(100);
            return;
        }

        // === Step 4: No gap yet, reverse slightly ===
        UART_Sendf("No gap yet (US=%.1f, IR=%.1f). Reversing...\r\n", us_dist, ir_dist);
        MoveBackwardDistance(duty, BACK_DIST_CM);
        Drive_brake();
        osDelay(PAUSE_MS);
    }
}


// === helpers ==============================================================
//static void FollowRightWall_UntilOpen(uint16_t duty, float step_cm)
//{
//    float ema = 0.0f;
//    bool present = false;
//
//    UART_Sendf("[RIGHT] Searching for wall (reversing)...\r\n");
//
//    //Reverse until wall detected (present = true)
//    for (int i = 0; i < 10; i++)
//    {
//        MoveBackwardDistance(duty, 2);
//        float raw = IR2_GetDistanceCm();
//        ema = (EMA_A * raw) + (1.0f - EMA_A) * ema;
//
//        if (!present && ema <= R_CLOSE_MAX && ema > 0.0f)
//        {
//            present = true;
//            UART_Sendf("   [RIGHT] Wall detected at %.1f cm\r\n", ema);
//            break;
//        }
//        osDelay(40);
//    }
//
//    Drive_brake();
//    osDelay(100);
//
//    if (!present)
//    {
//        UART_Sendf("   [RIGHT] No wall detected, skipping follow.\r\n");
//        return;
//    }
//
//    UART_Sendf("[RIGHT] Following wall until open...\r\n");
//
//    //Follow wall forward until it opens
//    for (int i = 0; i < 15; i++)
//    {
//        float raw = IR2_GetDistanceCm();
//        ema = (EMA_A * raw) + (1.0f - EMA_A) * ema;
//
//        if (present && ema >= R_OPEN_MIN)
//        {
//            present = false;
//            UART_Sendf("   [RIGHT] Wall opened at %.1f cm → stop\r\n", ema);
//            Drive_brake();
//            return;
//        }
//
//        MoveForwardDistance_us(duty, step_cm);
//        osDelay(30);
//    }
//
//    Drive_brake();
//}
//
//static void FollowRightWall_UntilOpen_long(uint16_t duty, float step_cm)
//{
//    float ema = 0.0f;
//    bool present = false;
//
//    UART_Sendf("[RIGHT] Searching for wall (reversing)...\r\n");
//
//    //Reverse until wall detected (present = true)
//    for (int i = 0; i < 10; i++)
//    {
//        MoveBackwardDistance(duty, 2);
//        float raw = IR2_GetDistanceCm();
//        ema = (EMA_A * raw) + (1.0f - EMA_A) * ema;
//
//        if (!present && ema <= R_CLOSE_MAX && ema > 0.0f)
//        {
//            present = true;
//            UART_Sendf("   [RIGHT] Wall detected at %.1f cm\r\n", ema);
//            break;
//        }
//        osDelay(40);
//    }
//
//    Drive_brake();
//    osDelay(100);
//
//    if (!present)
//    {
//        UART_Sendf("   [RIGHT] No wall detected, skipping follow.\r\n");
//        return;
//    }
//
//    UART_Sendf("[RIGHT] Following wall until open...\r\n");
//
//    //Follow wall forward until it opens
//    for (int i = 0; i < 30; i++)
//    {
//        float raw = IR2_GetDistanceCm();
//        ema = (EMA_A * raw) + (1.0f - EMA_A) * ema;
//
//        if (present && ema >= R_OPEN_MIN)
//        {
//            present = false;
//            UART_Sendf("   [RIGHT] Wall opened at %.1f cm → stop\r\n", ema);
//            Drive_brake();
//            return;
//        }
//
//        MoveForwardDistance_us(duty, step_cm);
//        osDelay(30);
//    }
//
//    Drive_brake();
//}


static void FollowRightWall_UntilOpen(uint16_t duty, float step_cm)
{
    float ema = 0.0f;
    bool present = false;

    UART_Sendf("[RIGHT] Searching for wall (reversing)...\r\n");

    //Reverse until wall detected (present = true)
    for (int i = 0; i < 10; i++)
    {
        MoveBackwardDistance(duty, 2);
        float raw = IR2_GetDistanceCm();
        ema = (EMA_A * raw) + (1.0f - EMA_A) * ema;

        if (!present && ema <= R_CLOSE_MAX && ema > 0.0f)
        {
            present = true;
            UART_Sendf("   [RIGHT] Wall detected at %.1f cm\r\n", ema);
            break;
        }
        osDelay(40);
    }

    Drive_brake();
    osDelay(100);

    if (!present)
    {
        UART_Sendf("   [RIGHT] No wall detected, skipping follow.\r\n");
        return;
    }

    UART_Sendf("[RIGHT] Following wall until open...\r\n");

    //Follow wall forward until it opens
    for (int i = 0; i < 15; i++)
    {
        float raw = IR2_GetDistanceCm();
        ema = (EMA_A * raw) + (1.0f - EMA_A) * ema;

        if (present && ema >= R_OPEN_MIN)
        {
            present = false;
            UART_Sendf("   [RIGHT] Wall opened at %.1f cm → stop\r\n", ema);
            Drive_brake();
            return;
        }

        MoveForwardDistance_us(duty, step_cm);
        osDelay(30);
    }

    Drive_brake();
}

static void FollowRightWall_UntilOpen_long(uint16_t duty, float step_cm)
{
    float ema = 0.0f;
    bool present = false;

    UART_Sendf("[RIGHT] Searching for wall (reversing)...\r\n");

    //Reverse until wall detected (present = true)
    for (int i = 0; i < 10; i++)
    {
        MoveBackwardDistance(duty, 2);
        float raw = IR2_GetDistanceCm();
        ema = (EMA_A * raw) + (1.0f - EMA_A) * ema;

        if (!present && ema <= R_CLOSE_MAX && ema > 0.0f)
        {
            present = true;
            UART_Sendf("   [RIGHT] Wall detected at %.1f cm\r\n", ema);
            break;
        }
        osDelay(40);
    }

    Drive_brake();
    osDelay(100);

    if (!present)
    {
        UART_Sendf("   [RIGHT] No wall detected, skipping follow.\r\n");
        return;
    }

    UART_Sendf("[RIGHT] Following wall until open...\r\n");

    //Follow wall forward until it opens
    for (int i = 0; i < 30; i++)
    {
        float raw = IR2_GetDistanceCm();
        ema = (EMA_A * raw) + (1.0f - EMA_A) * ema;

        if (present && ema >= R_OPEN_MIN)
        {
            present = false;
            UART_Sendf("   [RIGHT] Wall opened at %.1f cm → stop\r\n", ema);
            Drive_brake();
            return;
        }

        MoveForwardDistance_us(duty, step_cm);
        osDelay(30);
    }

    Drive_brake();
}


static void FollowLeftWall_UntilOpen(uint16_t duty, float step_cm)
{
    float ema = 0.0f;
    bool present = false;

    UART_Sendf("[LEFT] Searching for wall (reversing)...\r\n");

    // === Reverse until wall detected ===
    for (int i = 0; i < 10; i++)
    {
        MoveBackwardDistance(duty, 2);
        float raw = IR1_GetDistanceCm();
        ema = (EMA_A * raw) + (1.0f - EMA_A) * ema;
        UART_Sendf("   [LEFT][REV] raw=%.1f ema=%.1f present=%d\r\n", raw, ema, present);

        if (!present && ema <= L_CLOSE_MAX && ema > 0.0f)
        {
            present = true;
            UART_Sendf("   [LEFT] Wall detected at %.1f cm\r\n", ema);
            break;
        }
        osDelay(40);
    }

    Drive_brake();
    osDelay(100);

    if (!present)
    {
        UART_Sendf("   [LEFT] No wall detected, skipping follow.\r\n");
        return;
    }

    UART_Sendf("[LEFT] Following wall until open...\r\n");

    // === Follow wall forward until it opens ===
    for (int i = 0; i < 15; i++)
    {
        float raw = IR1_GetDistanceCm();
        ema = (EMA_A * raw) + (1.0f - EMA_A) * ema;
        UART_Sendf("   [LEFT][FWD] raw=%.1f ema=%.1f present=%d\r\n", raw, ema, present);

        if (present && ema >= L_OPEN_MIN)
        {
            present = false;
            UART_Sendf("   [LEFT] Wall opened at %.1f cm → stop\r\n", ema);
            Drive_brake();
            return;
        }

        MoveForwardDistance_us(duty, step_cm);
        osDelay(30);
    }

    Drive_brake();
}


static void FollowLeftWall_UntilOpen_long(uint16_t duty, float step_cm)
{
    float ema = 0.0f;
    bool present = false;

    UART_Sendf("[LEFT] Searching for wall (reversing)...\r\n");

    // === Reverse until wall detected ===
    for (int i = 0; i < 10; i++)
    {
        MoveBackwardDistance(duty, 2);
        float raw = IR1_GetDistanceCm();
        ema = (EMA_A * raw) + (1.0f - EMA_A) * ema;
        UART_Sendf("   [LEFT][REV] raw=%.1f ema=%.1f present=%d\r\n", raw, ema, present);

        if (!present && ema <= L_CLOSE_MAX && ema > 0.0f)
        {
            present = true;
            UART_Sendf("   [LEFT] Wall detected at %.1f cm\r\n", ema);
            break;
        }
        osDelay(40);
    }

    Drive_brake();
    osDelay(100);

    if (!present)
    {
        UART_Sendf("   [LEFT] No wall detected, skipping follow.\r\n");
        return;
    }

    UART_Sendf("[LEFT] Following wall until open (long)...\r\n");

    // === Follow wall forward until it opens ===
    for (int i = 0; i < 30; i++)
    {
        float raw = IR1_GetDistanceCm();
        ema = (EMA_A * raw) + (1.0f - EMA_A) * ema;
        UART_Sendf("   [LEFT][FWD] raw=%.1f ema=%.1f present=%d\r\n", raw, ema, present);

        if (present && ema >= L_OPEN_MIN)
        {
            present = false;
            UART_Sendf("   [LEFT] Wall opened at %.1f cm → stop\r\n", ema);
            Drive_brake();
            return;
        }

        MoveForwardDistance_us(duty, step_cm);
        osDelay(30);
    }

    Drive_brake();
}



//static void FollowLeftWall_UntilOpen(uint16_t duty, float step_cm)
//{
//    float ema = 0.0f;
//    bool present = false;
//
//    UART_Sendf("[LEFT] Searching for wall (reversing)...\r\n");
//
//    //Reverse until wall detected
//    for (int i = 0; i < 10; i++)
//    {
//        MoveBackwardDistance(duty, 2);
//        float raw = IR1_GetDistanceCm();
//        ema = (EMA_A * raw) + (1.0f - EMA_A) * ema;
//
//        if (!present && ema <= L_CLOSE_MAX && ema > 0.0f)
//        {
//            present = true;
//            UART_Sendf("   [LEFT] Wall detected at %.1f cm\r\n", ema);
//            break;
//        }
//        osDelay(40);
//    }
//
//    Drive_brake();
//    osDelay(100);
//
//    if (!present)
//    {
//        UART_Sendf("   [LEFT] No wall detected, skipping follow.\r\n");
//        return;
//    }
//
//    UART_Sendf("[LEFT] Following wall until open...\r\n");
//
//    //Follow wall forward until it opens
//    for (int i = 0; i < 15; i++)
//    {
//        float raw = IR1_GetDistanceCm();
//        ema = (EMA_A * raw) + (1.0f - EMA_A) * ema;
//
//        if (present && ema >= L_OPEN_MIN)
//        {
//            present = false;
//            UART_Sendf("   [LEFT] Wall opened at %.1f cm → stop\r\n", ema);
//            Drive_brake();
//            return;
//        }
//
//        MoveForwardDistance_us(duty, step_cm);
//        osDelay(30);
//    }
//
//    Drive_brake();
//}
//
//
//static void FollowLeftWall_UntilOpen_long(uint16_t duty, float step_cm)
//{
//    float ema = 0.0f;
//    bool present = false;
//
//    UART_Sendf("[LEFT] Searching for wall (reversing)...\r\n");
//
//    //Reverse until wall detected
//    for (int i = 0; i < 10; i++)
//    {
//        MoveBackwardDistance(duty, 2);
//        float raw = IR1_GetDistanceCm();
//        ema = (EMA_A * raw) + (1.0f - EMA_A) * ema;
//
//        if (!present && ema <= L_CLOSE_MAX && ema > 0.0f)
//        {
//            present = true;
//            UART_Sendf("   [LEFT] Wall detected at %.1f cm\r\n", ema);
//            break;
//        }
//        osDelay(40);
//    }
//
//    Drive_brake();
//    osDelay(100);
//
//    if (!present)
//    {
//        UART_Sendf("   [LEFT] No wall detected, skipping follow.\r\n");
//        return;
//    }
//
//    UART_Sendf("[LEFT] Following wall until open...\r\n");
//
//    //Follow wall forward until it opens
//    for (int i = 0; i < 30; i++)
//    {
//        float raw = IR1_GetDistanceCm();
//        ema = (EMA_A * raw) + (1.0f - EMA_A) * ema;
//
//        if (present && ema >= L_OPEN_MIN)
//        {
//            present = false;
//            UART_Sendf("   [LEFT] Wall opened at %.1f cm → stop\r\n", ema);
//            Drive_brake();
//            return;
//        }
//
//        MoveForwardDistance_us(duty, step_cm);
//        osDelay(30);
//    }
//
//    Drive_brake();
//}

// Wide corners (reverse–forward–turn)

static void CornerRight_Wide(uint16_t duty)
{
    MoveForwardDistance(duty, 10);
    TurnForward(-90, duty);
    osDelay(80);
}

static void CornerLeft_Wide(uint16_t duty)
{
    MoveForwardDistance(duty, 10);
    TurnForward(+90, duty);
    osDelay(80);
}


//static void PostZAutoForward(uint16_t duty)
//{
//    // ---- tunables (keep simple) ----
//    const float MARGIN_CM   = 20.0f;
//    const float MIN_BASE_CM = 5.0f;
//    const float MAX_BASE_CM = 200.0f;
//    const float CHUNK_CM    = 10.0f;
//    const float US_SAFE_CM  = 12.0f;    // hard stop if < this
//
//    // ---- compute base from snapshots or fallback ----
//    float base_cm = 100.0f;
//    if (g_first_obstacle_saved && g_second_obstacle_saved) {
//        int32_t dticks = g_ticks_at_second_obstacle - g_ticks_at_first_obstacle;
//        UART_Sendf("SNAP,flags f=%d s=%d dticks=%ld TPC=%.3f\r\n",
//                   g_first_obstacle_saved, g_second_obstacle_saved,
//                   (long)dticks, (double)TICKS_PER_CM);
//        if (dticks > 0) base_cm = ((float)dticks) / TICKS_PER_CM;
//        else UART_Sendf("SNAP,BAD_ORDER -> fallback 100cm\r\n");
//    } else {
//        UART_Sendf("SNAP,MISSING -> fallback 100cm\r\n");
//    }
//
//    // clamp
//    if (base_cm < MIN_BASE_CM) base_cm = MIN_BASE_CM;
//    if (base_cm > MAX_BASE_CM) base_cm = MAX_BASE_CM;
//
//    const float target_cm = base_cm + MARGIN_CM;
//    UART_Sendf("POSTZ,PLAN base=%.1f margin=%.1f target=%.1f\r\n",
//               base_cm, MARGIN_CM, target_cm);
//
//    // ---- pre-move ultrasonic safety ----
//    float us_cm = 0.0f; uint8_t us_ok = 0;
//    {   uint32_t pm = __get_PRIMASK(); __disable_irq();
//        us_cm = g_latest_dist_cm;
//        us_ok = g_us_valid && ((HAL_GetTick() - g_us_ts_ms) <= US_FRESH_MS);
//        __set_PRIMASK(pm);
//    }
//    if (us_ok && us_cm > 0.0f && us_cm < US_SAFE_CM) {
//        UART_Sendf("POSTZ,ABORT pre-US=%.1fcm (too close)\r\n", us_cm);
//        Drive_brake();
//        return;
//    }
//
//    // ---- chunked move with US re-checks ----
//    float remaining = target_cm, moved = 0.0f;
//    while (remaining > 0.5f) {
//        float step = (remaining > CHUNK_CM) ? CHUNK_CM : remaining;
//
//        MoveForwardDistance_us(duty, step);
//        Drive_brake();
//        moved += step;
//        remaining -= step;
//
//        // re-check US
//        {   uint32_t pm = __get_PRIMASK(); __disable_irq();
//            us_cm = g_latest_dist_cm;
//            us_ok = g_us_valid && ((HAL_GetTick() - g_us_ts_ms) <= US_FRESH_MS);
//            __set_PRIMASK(pm);
//        }
//        if (us_ok && us_cm > 0.0f && us_cm < US_SAFE_CM) {
//            UART_Sendf("POSTZ,EARLY_STOP US=%.1fcm moved=%.1f/%.1f\r\n",
//                       us_cm, moved, target_cm);
//            break;
//        }
//    }
//
//    UART_Sendf("ACK,POSTZ,FORWARD_DONE moved=%.1f target=%.1f\r\n", moved, target_cm);
//
//    // optional: consume snapshots so next run won’t reuse old ones
//    g_first_obstacle_saved = false;
//    g_second_obstacle_saved = false;
//}


static void PostZAutoForward(uint16_t duty)
{
    // ===== Compute forward distance (tick-based corridor length) =====
    float forward_cm = 100.0f;  // default fallback
    if (g_first_obstacle_saved && g_second_obstacle_saved)
    {
        int32_t dticks = g_ticks_at_second_obstacle - g_ticks_at_first_obstacle;
        if (dticks > 0)
            forward_cm = ((float)dticks) / TICKS_PER_CM;
    }
    forward_cm += 20.0f;  // add a small safety margin

    UART_Sendf("[PostZ] Moving forward; target distance = %.1f cm\r\n", forward_cm);

    // ===== Constants =====
    const float STEP_CM       = 3.0f;
    const float DIP_THRESHOLD = 8.0f;   // sudden gap increase = new corner
    const float IR_MIN_VALID  = 2.0f;

    // store previous IRs
    static float prevL = -1.0f, prevR = -1.0f;

    // traveled distance tracking
    float traveled = 0.0f;

    for (;;)
    {
        float distL = IR1_GetDistanceCm();
        float distR = IR2_GetDistanceCm();

        // ignore invalid zero/negative readings
        if (distL < IR_MIN_VALID) distL = prevL;
        if (distR < IR_MIN_VALID) distR = prevR;

        // compute delta for "dip" detection
        float deltaL = (prevL > 0) ? (distL - prevL) : 0.0f;
        float deltaR = (prevR > 0) ? (distR - prevR) : 0.0f;
        prevL = distL;
        prevR = distR;

        // check conditions
        bool left_gap  = (deltaL > DIP_THRESHOLD);   // sudden increase left
        bool right_gap = (deltaR > DIP_THRESHOLD);   // sudden increase right
        bool exceeded_distance = (traveled >= forward_cm);

        if (left_gap || right_gap || exceeded_distance)
        {
            UART_Sendf("[PostZ] Event triggered! ΔL=%.1f ΔR=%.1f  Traveled=%.1f/%.1f\r\n",
                       deltaL, deltaR, traveled, forward_cm);
            Drive_brake();
            osDelay(250);

            // if tick limit exceeded — repeat last turn direction
            if (exceeded_distance)
            {
                if (g_last_turn_dir == 'R')
                {
                    UART_Sendf("[PostZ] Passed segment → turning RIGHT again (same dir)\r\n");
                    TurnForward(-90, duty);
                }
                else if (g_last_turn_dir == 'L')
                {
                    UART_Sendf("[PostZ] Passed segment → turning LEFT again (same dir)\r\n");
                    TurnForward(+90, duty);
                }
                else
                {
                    UART_Sendf("[PostZ] No last turn direction saved; stopping.\r\n");
                }
                break;
            }

            // otherwise, dip-based turn
            if (left_gap && !right_gap)
            {
                UART_Sendf("[PostZ] LEFT gap detected → turning LEFT 90°\r\n");
                TurnForward(+45, duty);
                MoveForwardDistance(duty, 10);
                TurnForward(+45, duty);
                g_last_turn_dir = 'L';
            }
            else if (right_gap && !left_gap)
            {
                UART_Sendf("[PostZ] RIGHT gap detected → turning RIGHT 90°\r\n");
                TurnForward(-45, duty);
                MoveForwardDistance(duty, 10);
                TurnForward(-45, duty);
                g_last_turn_dir = 'R';
            }
            else
            {
                UART_Sendf("[PostZ] Both sides open or ambiguous → keep direction\r\n");
            }

            Drive_brake();
            osDelay(200);
            break;  // exit loop for ultrasonic fine alignment
        }

        // continue small forward increments
        MoveForwardDistance_us(duty, STEP_CM);
        traveled += STEP_CM;
        osDelay(30);
    }

    // ===== Ultrasonic fine approach =====
    UART_Sendf("[PostZ] Performing ultrasonic alignment...\r\n");
    Drive_brake();
    osDelay(150);

    float dist = 0.0f;
    uint8_t dist_valid = 0;
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    dist = g_latest_dist_cm;
    dist_valid = g_us_valid && ((HAL_GetTick() - g_us_ts_ms) <= US_FRESH_MS);
    __set_PRIMASK(primask);

    if (!dist_valid)
    {
        UART_Sendf("[US] No fresh reading → reversing 25cm\r\n");
        MoveBackwardDistance(duty, 25);
    }
    else if (dist < 20.0f)
    {
        UART_Sendf("[US] Too close (%.1f cm) → reversing 10cm\r\n", dist);
        MoveBackwardDistance(duty, 10);
    }
    else if (dist > 35.0f)
    {
        UART_Sendf("[US] Too far (%.1f cm) → moving forward 10cm\r\n", dist);
        MoveForwardDistance_us(duty, 10);
    }
    else
    {
        UART_Sendf("[US] Clearance OK (%.1f cm)\r\n", dist);
    }

    Drive_brake();
    UART_Sendf("ACK,POSTZ,FORWARD,%.1f\r\n", forward_cm);
}



void StartCommandHandlerTask(void *argument)
{
    char cmd[CMD_BUF_SIZE];
    const uint16_t duty_normal = (uint16_t)(htim8.Init.Period * 30 / 100);  // ~30%
    const uint16_t duty_lower  = (uint16_t)(htim8.Init.Period * 20 / 100);  // ~20%
    int value = atoi(&cmd[1]);  // 0 if no number is provided


    //UART_Sendf("Waiting for first command (U)...\r\n");
    while (1)
    {
        if (osMessageQueueGet(motorQueue, cmd, NULL, osWaitForever) == osOK)
        {
            if (cmd[0] == 'U')
            {
                //UART_Sendf("Received initial command: %s\r\n", cmd);
                break;
            }
        }
        osDelay(2);
    }

    //UART_Sendf("Executing command handler main loop...\r\n");
    osDelay(2);

    for (;;)
    {
        char action = cmd[0];
        osDelay(2);

        switch (action)
        {
            // --------------------------------------------------
            case 'U':  // Move forward fixed distance (150 cm)
                MoveForwardDistance_us(duty_lower, 150);
                osDelay(1);
                UART_Sendf("ACK\r\n");  // Simple ACK after forward move
                osDelay(2);
                while (1)
                    {
                        if (osMessageQueueGet(motorQueue, cmd, NULL, osWaitForever) == osOK)
                        {
                            if (cmd[0] == 'X' || cmd[0] == 'Y'  )
                            {
                                //UART_Sendf("Received Second command: %s\r\n", cmd);
                                break;
                            }
                        }
                        osDelay(2);
                    }

                break;

            // --------------------------------------------------
            case 'X':  // LEFT path → pillar on RIGHT IR
            case 'Y':  // RIGHT path → pillar on LEFT IR
            {
                const uint16_t duty = duty_normal;
                const float SNAP_TARGET = 25.0f;
                const float SNAP_MARGIN = 3.0f;

                if (action == 'Y')
                {
                    TurnForward(-45, duty);
                    MoveForwardDistance(duty, 15);
                    TurnForward(+45, duty);

                    uint32_t start_time = HAL_GetTick();
                    while (1)
                    {
                        MoveBackwardDistance(duty, 1);
                        float distR = IR1_GetDistanceCm();  // RIGHT IR
                        //UART_Sendf("IR-R = %.2f cm\r\n", distR);
                        osDelay(10);

                        if (distR > 0 && distR <= SNAP_TARGET + SNAP_MARGIN)
                        {
                            //UART_Sendf("Pillar detected at %.1f cm (RIGHT IR)\r\n", distR);
                            Drive_brake();
                            break;
                        }

                        if (HAL_GetTick() - start_time > 1000)
                        {
                            //UART_Sendf("Timeout — no pillar found\r\n");
                            Drive_brake();
                            break;
                        }
                    }

                    TurnForward(+45, duty);
                    MoveForwardDistance_us(duty, 15);
                    TurnForward(-45, duty);
                    //UART_Sendf("LEFT path pillar alignment complete\r\n");
                }
                else
                {
                    TurnForward(+45, duty);
                    MoveForwardDistance(duty, 15);
                    TurnForward(-35, duty);

                    uint32_t start_time = HAL_GetTick();
                    while (1)
                    {
                        MoveBackwardDistance(duty, 1);
                        float distL = IR2_GetDistanceCm();  // LEFT IR
                        //UART_Sendf("IR-L = %.2f cm\r\n", distL);
                        osDelay(10);

                        if (distL > 0 && distL <= SNAP_TARGET + SNAP_MARGIN)
                        {
                            //UART_Sendf("Pillar detected at %.1f cm (LEFT IR)\r\n", distL);
                            Drive_brake();
                            break;
                        }

                        if (HAL_GetTick() - start_time > 1000)
                        {
                            //UART_Sendf("Timeout — no pillar found\r\n");
                            Drive_brake();
                            break;
                        }
                    }

                    TurnForward(-45, duty);
                    MoveForwardDistance_us(duty, 15);
                    TurnForward(+45, duty);
                    //UART_Sendf("RIGHT path pillar alignment complete\r\n");
                }

                Drive_brake();
                osDelay(1500);

                // === Ultrasonic clearance check ===
                float dist = 0.0f;
                uint8_t dist_valid = 0;
                uint32_t primask = __get_PRIMASK();
                __disable_irq();
                dist = g_latest_dist_cm;
                dist_valid = g_us_valid && ((HAL_GetTick() - g_us_ts_ms) <= US_FRESH_MS);
                __set_PRIMASK(primask);

                if (!dist_valid)
                {
                    //UART_Sendf("[US] No fresh ultrasonic reading. Assuming too near → reversing 25cm\r\n");
                    MoveBackwardDistance(duty, 25);
                    Drive_brake();
                    osDelay(300);
                }
                else
                {
                    //UART_Sendf("[US] Measured distance = %.1f cm\r\n", dist);

                    if (dist < 20.0f)
                    {
                        //UART_Sendf("[US] Too close (%.1f cm)! Reversing 10cm...\r\n", dist);
                        MoveBackwardDistance(duty, 10);
                        Drive_brake();
                        osDelay(300);
                    }
                    else if (dist > 35.0f)
                    {
                        //UART_Sendf("[US] Too far (%.1f cm)! Moving forward 10cm...\r\n", dist);
                        MoveForwardDistance_us(duty_lower, 120);
                        Drive_brake();
                        osDelay(300);
                    }
                    else
                    {
                        //UART_Sendf("[US] Clearance OK (%.1f cm)\r\n", dist);
                        Drive_brake();
                        osDelay(150);
                    }
                }

                Drive_brake();
                UART_Sendf("ACK\r\n");
                osDelay(300);

                // === SECOND OBSTACLE HANDLER (AUTOMATED VERSION, NO STEP 0–1) ===
                //UART_Sendf("Starting automatic SECOND OBSTACLE routine...\r\n");

                const uint16_t duty_z = duty_normal;

                // Thresholds and constants
                const float INCH_FWD_CM = 5.0f, TRACK_STEP = 3.0f, TRAVEL_CAP = 150.0f;
                static float r_ema = 0.0f, l_ema = 0.0f;
                static bool  r_present = false, l_present = false;

                // EMA smoothing macros
                #define UPDATE_RIGHT_PRESENT(raw) do { \
                    r_ema = (EMA_A * (raw)) + (1.0f - EMA_A) * r_ema; \
                    if (r_present) { if (r_ema >= R_OPEN_MIN) r_present = false; } \
                    else { if (r_ema <= R_CLOSE_MAX && r_ema > 0.0f) r_present = true; } \
                } while (0)

                #define UPDATE_LEFT_PRESENT(raw) do { \
                    l_ema = (EMA_A * (raw)) + (1.0f - EMA_A) * l_ema; \
                    if (l_present) { if (l_ema >= L_OPEN_MIN) l_present = false; } \
                    else { if (l_ema <= L_CLOSE_MAX && l_ema > 0.0f) l_present = true; } \
                } while (0)

                // === Wait for D or E (side selection) ===
                //UART_Sendf("ACK\r\n");
                //UART_Sendf("Waiting for D(left) or E(right)...\r\n");

                char sideCmd[CMD_BUF_SIZE];
                if (osMessageQueueGet(motorQueue, sideCmd, NULL, osWaitForever) == osOK)
                {
                    // ------------------------------------------------------
                    // LEFT PATH SEQUENCE (D)
                    // ------------------------------------------------------
                	// ===== D/E handling: rectangle with same-sensor tracking and wide corners =====
                	// ===== D/E handling (rectangle logic) =====
                	const float TRACK_STEP = 2.0f;   // larger step to avoid constant stops

                	if (sideCmd[0] == 'D')  // LEFT → follow RIGHT IR
                	{
                	    TurnForward(+90, duty);

                	    MoveBackwardDistance(duty, 8);
                	    MoveForwardDistance_us(duty, 3);     // <-- new stabilising nudge
                	    FollowRightWall_UntilOpen(duty, TRACK_STEP);
                	    CornerRight_Wide(duty);

                	    MoveBackwardDistance(duty, 8);
                	    MoveForwardDistance_us(duty, 3);
                	    FollowRightWall_UntilOpen(duty, TRACK_STEP);
                	    CornerRight_Wide(duty);

                	    MoveBackwardDistance(duty, 8);
                	    MoveForwardDistance_us(duty, 3);
                	    FollowRightWall_UntilOpen_long(duty, TRACK_STEP);
                	    CornerRight_Wide(duty);

                	    Drive_brake();
                	}
                	else if (sideCmd[0] == 'E')  // RIGHT → follow LEFT IR
                	{
                	    TurnForward(-90, duty);

                	    MoveBackwardDistance(duty, 8);
                	    MoveForwardDistance_us(duty, 3);
                	    FollowLeftWall_UntilOpen(duty, TRACK_STEP);
                	    CornerLeft_Wide(duty);

                	    MoveBackwardDistance(duty, 8);
                	    MoveForwardDistance_us(duty, 3);
                	    FollowLeftWall_UntilOpen(duty, TRACK_STEP);
                	    CornerLeft_Wide(duty);

                	    MoveBackwardDistance(duty, 8);
                	    MoveForwardDistance_us(duty, 3);
                	    FollowLeftWall_UntilOpen_long(duty, TRACK_STEP);
                	    CornerLeft_Wide(duty);

                	    Drive_brake();
                	}

                	UART_Sendf("ACK\r\n");
                }
            }


            case 'P':  // Post-Z: detect parking gap by IR dip and turn in
            {
                const uint16_t duty = duty_normal;
                const float STEP_CM = 2.0f;
                const float DIP_THRESHOLD = 8.0f;   // sudden increase = gap
                const float IR_MIN_VALID = 2.0f;

                UART_Sendf("[POST-Z] Starting return-to-carpark sequence...\r\n");

                // Step 1: move forward buffer first to clear wall
                MoveForwardDistance_us(duty, 40);
                Drive_brake();
                osDelay(300);

                // previous IR values
                float prevL = IR1_GetDistanceCm();
                float prevR = IR2_GetDistanceCm();

                for (;;)
                {
                    float distL = IR1_GetDistanceCm();
                    float distR = IR2_GetDistanceCm();

                    if (distL < IR_MIN_VALID) distL = prevL;
                    if (distR < IR_MIN_VALID) distR = prevR;

                    float deltaL = distL - prevL;
                    float deltaR = distR - prevR;

                    UART_Sendf("[POST-Z] L=%.1f (Δ=%.1f) | R=%.1f (Δ=%.1f)\r\n", distL, deltaL, distR, deltaR);

                    prevL = distL;
                    prevR = distR;

                    // check for DIP (gap)
                    if (deltaL > DIP_THRESHOLD || deltaR > DIP_THRESHOLD)
                    {
                        Drive_brake();
                        osDelay(150);

                        if (deltaL > deltaR)
                        {
                            UART_Sendf("[POST-Z] LEFT gap detected → turning LEFT 90° into carpark\r\n");
                            TurnForward(-90, duty);
                            MoveForwardDistance(duty, 10);
                            TurnForward(+90, duty);
                        }
                        else
                        {
                            UART_Sendf("[POST-Z] RIGHT gap detected → turning RIGHT 90° into carpark\r\n");
                            TurnForward(+90, duty);
                            MoveForwardDistance(duty, 10);
                            TurnForward(-90, duty);
                        }

                        Drive_brake();
                        osDelay(200);

                        // === Ultrasonic stop inside carpark ===
                        UART_Sendf("[POST-Z] Using ultrasonic to park precisely...\r\n");

                        float dist = 0.0f;
                        uint8_t dist_valid = 0;
                        uint32_t primask = __get_PRIMASK();
                        __disable_irq();
                        dist = g_latest_dist_cm;
                        dist_valid = g_us_valid && ((HAL_GetTick() - g_us_ts_ms) <= US_FRESH_MS);
                        __set_PRIMASK(primask);

                        if (dist_valid)
                        {
                            while (dist > 20.0f)
                            {
                                MoveForwardDistance_us(duty, 3);
                                Drive_brake();
                                osDelay(100);

                                __disable_irq();
                                dist = g_latest_dist_cm;
                                dist_valid = g_us_valid && ((HAL_GetTick() - g_us_ts_ms) <= US_FRESH_MS);
                                __set_PRIMASK(primask);

                                UART_Sendf("[US] dist = %.1f cm\r\n", dist);
                                if (!dist_valid) break;
                            }
                        }

                        Drive_brake();
                        UART_Sendf("[POST-Z] Parked. ACK,P,COMPLETE\r\n");
                        break;
                    }

                    // keep moving forward small steps
                    MoveForwardDistance_us(duty, STEP_CM);
                    osDelay(40);
                }

                break;
            }


            // --------------------------------------------------
            default:
                UART_Sendf("Unknown command: %s\r\n", cmd);
                osDelay(2);
                break;
        }

        // === Wait for next command ===
        if (osMessageQueueGet(motorQueue, cmd, NULL, osWaitForever) != osOK)
            continue;
        osDelay(2);
    }
}


void StartUltrasonicTask(void *argument)
{
    // Hardware initialization
    __HAL_RCC_TIM12_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin       = Ultrasonic_Echo_Pin;
    GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull      = GPIO_PULLDOWN;
    GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF9_TIM12;
    HAL_GPIO_Init(Ultrasonic_Echo_GPIO_Port, &GPIO_InitStruct);

    // Ensure TIM12 is running
    MX_TIM12_Init();
    __HAL_TIM_ENABLE(&htim12);
    __HAL_TIM_ENABLE_IT(&htim12, TIM_IT_CC2);
    HAL_NVIC_SetPriority(TIM8_BRK_TIM12_IRQn, 5, 0);
    HAL_NVIC_EnableIRQ(TIM8_BRK_TIM12_IRQn);
    HAL_TIM_IC_Start_IT(&htim12, TIM_CHANNEL_2);

    float lpf = 0.0f;
    const float ALPHA = 0.5f;  // Fast response for obstacle detection

    // Small startup delay
    osDelay(100);

    for (;;)
    {
        // Reset measurement flags
        echo_ready = 0;
        echo = 0;
        is_rising = 1;

        // Trigger pulse
        HCSR04_Trig();

        // Wait for echo with timeout
        uint32_t timeout_start = HAL_GetTick();
        while (!echo_ready && (HAL_GetTick() - timeout_start) < 50) {
            osDelay(1);
        }

        // Process valid echo
        if (echo_ready && echo > 10) {
            float d_cm = (echo * 0.0343f) * 0.5f;

            // Sanity checks
            if (d_cm < 2.0f)   d_cm = 2.0f;
            if (d_cm > 400.0f) d_cm = 400.0f;

            // Low-pass filter
            if (lpf == 0.0f) {
                lpf = d_cm;  // First reading
            } else {
                lpf = (1.0f - ALPHA) * lpf + ALPHA * d_cm;
            }

            // Update globals ATOMICALLY (prevent race conditions)
            __disable_irq();
            g_latest_dist_cm = lpf;
            g_us_valid = 1;
            g_us_ts_ms = HAL_GetTick();
            __enable_irq();
        } else {
            // No valid echo this cycle
            __disable_irq();
            g_us_valid = 0;
            __enable_irq();
        }

        // Fast update rate for safety (30ms = ~33Hz)
        osDelay(200);
    }
}

//GYROSCOPE
void readByte(uint8_t addr, uint8_t *data)
{
    gyroBuffer[0] = addr;
    HAL_I2C_Master_Transmit(&hi2c2, ICMAddress << 1, gyroBuffer, 1, 10);
    HAL_I2C_Master_Receive(&hi2c2, ICMAddress << 1, data, 2, 20);
}

void writeByte(uint8_t addr, uint8_t data)
{
    gyroBuffer[0] = addr;
    gyroBuffer[1] = data;
    HAL_I2C_Master_Transmit(&hi2c2, ICMAddress << 1, gyroBuffer, 2, 20);
}

void gyroInit(void) {
	writeByte(0x06, 0x00); osDelay(10);
	writeByte(0x03, 0x80); osDelay(10);
	writeByte(0x07, 0x07); osDelay(10);
    writeByte(0x06, 0x01); osDelay(10);
    writeByte(0x7F, 0x20); osDelay(10);
    writeByte(0x01, 0x2F); osDelay(10);
    writeByte(0x00, 0x00); osDelay(10);
    writeByte(0x7F, 0x00); osDelay(10);
    writeByte(0x07, 0x00); osDelay(10);
}

//GYROSCOPE TEST TASK
void StartGyroTask(void *argument)
{
	gyroInit();

	uint8_t val[2] = {0, 0};
	int16_t angular_velocity = 0;
	int16_t prev_angular_velocity = 0;
	float turn_angle_temp = 0; // angle in degrees
	int offset = 0;

	// Calculate gyro offset (stationary)
	offset = 0;
	for (int i = 0; i < 200; i++) {
		osDelay(5);
		readByte(0x37, val);
		angular_velocity = (int16_t)((val[0] << 8) | val[1]);
		offset += angular_velocity;
	}
	offset /= 200;

	uint32_t tick = HAL_GetTick();
	const int16_t noise_threshold = 2;  // raw units
	//3.0 works for 90 degrees , 6.0 works for 180 degrees , 8.0 works for 270,360 degrees
	const float sensitivity = 16.4f; //16.4f default;    // LSB per °/s
	const int16_t max_raw = 32767;      // sanity check

	for (;;) {
		// Read raw gyro
		readByte(0x37, val);
		int16_t raw = (int16_t)((val[0] << 8) | val[1]) - offset;

		// Noise filter
		if (abs(raw) < noise_threshold) raw = 0;

		// Clamp spikes
		if (abs(raw) > max_raw) raw = prev_angular_velocity;

		// Convert to degrees/sec
		float angular_velocity_dps = (float)raw / sensitivity;
		float prev_angular_velocity_dps = (float)prev_angular_velocity / sensitivity;

		// Compute delta time
		uint32_t current_tick = HAL_GetTick();
		float delta_time = (current_tick - tick) / 1000.0f; // seconds
		tick = current_tick;

		// Integrate to get angle in degrees
		turn_angle_temp += (angular_velocity_dps + prev_angular_velocity_dps) * 0.5f * delta_time;
		prev_angular_velocity = raw;

		// Apply small deadzone near 0 to avoid jitter
		if (fabs(turn_angle_temp) < 0.5f) turn_angle_temp = 0;

		// Update global angle
		turn_angle = turn_angle_temp;

		// OLED update every 50ms
//		static uint32_t last_oled = 0;
//		if(current_tick - last_oled > 50) {
//			last_oled = current_tick;
//			char buf[35];
//			int rounded = (int)roundf(turn_angle_temp);
//			sprintf(buf,"angle:%d",rounded);
//			OLED_Clear();
//			OLED_ShowString(0,0,(uint8_t*)buf);
//			OLED_Refresh_Gram();
//		}

		// Round properly for OLED display
//		int rounded_angle = (int)roundf(turn_angle_temp);
//		char displayStr[35];
//		sprintf(displayStr, "angle: %d deg", rounded_angle); //-110
//		OLED_Clear();
//		OLED_ShowString(0, 10, (uint8_t*)displayStr);
//		OLED_Refresh_Gram();

		osDelay(1); // small delay for stability
	}
}

//IR sensors

uint16_t IR1_ReadRaw(void) {
    ADC_ChannelConfTypeDef sConfig = {0};
    sConfig.Channel = ADC_CHANNEL_4;   // PA4
    sConfig.Rank = 1;
    sConfig.SamplingTime = ADC_SAMPLETIME_84CYCLES;

    HAL_ADC_ConfigChannel(&hadc1, &sConfig);
    HAL_ADC_Start(&hadc1);
    HAL_ADC_PollForConversion(&hadc1, 10);
    uint16_t raw = HAL_ADC_GetValue(&hadc1);
    HAL_ADC_Stop(&hadc1);

    ir1_buf[ir1_idx] = raw;
    ir1_idx = (ir1_idx + 1) % IR_FILTER_LEN;
    uint32_t sum = 0;
    for (int i = 0; i < IR_FILTER_LEN; i++) sum += ir1_buf[i];
    return (uint16_t)(sum / IR_FILTER_LEN);
}


uint16_t IR2_ReadRaw(void) {
    ADC_ChannelConfTypeDef sConfig = {0};
    sConfig.Channel = ADC_CHANNEL_5;   // PA5
    sConfig.Rank = 1;
    sConfig.SamplingTime = ADC_SAMPLETIME_84CYCLES;

    HAL_ADC_ConfigChannel(&hadc1, &sConfig);
    HAL_ADC_Start(&hadc1);
    HAL_ADC_PollForConversion(&hadc1, 10);
    uint16_t raw = HAL_ADC_GetValue(&hadc1);
    HAL_ADC_Stop(&hadc1);

    ir2_buf[ir2_idx] = raw;
    ir2_idx = (ir2_idx + 1) % IR_FILTER_LEN;
    uint32_t sum = 0;
    for (int i = 0; i < IR_FILTER_LEN; i++) sum += ir2_buf[i];
    return (uint16_t)(sum / IR_FILTER_LEN);
}


// --- Distance calculation ---
float IR_VtoCm(float v)
{
    if (v < 0.13f) return -1.0f;  // avoid blow-up
    float d = 21.714f / (v - 0.1286f);
    if (d < 3.0f || d > 80.0f) return -1.0f;
    return d;
}

float IR1_GetDistanceCm(void) {
    uint16_t raw = IR1_ReadRaw();
    float v = (3.3f * raw) / 4095.0f;
    return IR_VtoCm(v);
}

float IR2_GetDistanceCm(void) {
    uint16_t raw = IR2_ReadRaw();
    float v = (3.3f * raw) / 4095.0f;
    return IR_VtoCm(v);
}

void IR_Display(float distanceCm, uint16_t x, uint16_t y) {
    char buff[32];
    if (distanceCm > 0.0f)
        sprintf(buff, "IR: %.1f cm", distanceCm);
    else
        sprintf(buff, "IR: No Obj");
    OLED_ShowString(x, y, (uint8_t*)buff);
    OLED_Refresh_Gram();
}

/* --- IR Sensor FreeRTOS Task --- */

void StartIRSensorTask(void *argument)
{
    // Small startup delay
    osDelay(200);

    for (;;) {
        // Read both sensors with a small gap
        float left = IR1_GetDistanceCm();
        osDelay(10);  // Small delay between sensor reads
        float right = IR2_GetDistanceCm();

        // Update globals atomically
        __disable_irq();
        g_irLeftDist = left;
        g_irRightDist = right;
        __enable_irq();

        // Update at ~5Hz (slower update = less ADC conflicts)
        osDelay(200);
    }
}



//OLED TASK

/* USER CODE BEGIN 4 */



// Add this OLED task implementation
void StartOledTask(void *argument)
{
    static char line1[32];
    static char line2[32];
    static char line3[32];
    static char line4[32];
    static char line5[32];

    // ============ GYRO INITIALIZATION ============
    gyroInit();

    static uint8_t gyro_val[2];
    int16_t gyro_angular_velocity = 0;
    int16_t gyro_prev_angular_velocity = 0;
    float turn_angle_temp = 0;
    int gyro_offset = 0;

    // Calculate gyro offset
    for (int i = 0; i < 200; i++) {
        osDelay(5);
        readByte(0x37, gyro_val);
        gyro_angular_velocity = (int16_t)((gyro_val[0] << 8) | gyro_val[1]);
        gyro_offset += gyro_angular_velocity;
    }
    gyro_offset /= 200;

    uint32_t gyro_tick = HAL_GetTick();
    const int16_t noise_threshold = 4;
    const float sensitivity = 16.4f;
    const int16_t max_raw = 32767;

    // ============ INITIAL DISPLAY ============
    OLED_Clear();
    OLED_ShowString(0, 0, (uint8_t*)"System Ready");
    OLED_Refresh_Gram();
    osDelay(1000);

    uint32_t last_oled_update = 0;
    const uint32_t OLED_UPDATE_INTERVAL_MS = 200;  // 5Hz display refresh

    // ============ MAIN LOOP ============
    for (;;)
    {
        uint32_t now = osKernelGetTickCount();

        // -------- UPDATE GYRO (every loop iteration) --------
        readByte(0x37, gyro_val);
        int16_t raw = (int16_t)((gyro_val[0] << 8) | gyro_val[1]) - gyro_offset;

        // Noise filter
        if (abs(raw) < noise_threshold) raw = 0;
        if (abs(raw) > max_raw) raw = gyro_prev_angular_velocity;

        // Convert to degrees/sec
        float angular_velocity_dps = (float)raw / sensitivity;
        float prev_angular_velocity_dps = (float)gyro_prev_angular_velocity / sensitivity;

        // Time delta
        uint32_t current_tick = HAL_GetTick();
        float delta_time = (current_tick - gyro_tick) / 1000.0f;
        gyro_tick = current_tick;

        // Integrate angle
        turn_angle_temp += (angular_velocity_dps + prev_angular_velocity_dps) * 0.5f * delta_time;
        gyro_prev_angular_velocity = raw;

        if (fabsf(turn_angle_temp) < 0.5f) turn_angle_temp = 0;

        // Update global angle
        turn_angle = turn_angle_temp;

        // -------- UPDATE OLED DISPLAY --------
        if ((now - last_oled_update) >= OLED_UPDATE_INTERVAL_MS)
        {
            last_oled_update = now;

            // Read ultrasonic data atomically
            float dist_cm;
            uint8_t dist_valid;
            uint32_t dist_age_ms;

            __disable_irq();
            dist_cm = g_latest_dist_cm;
            dist_valid = g_us_valid;
            dist_age_ms = HAL_GetTick() - g_us_ts_ms;
            __enable_irq();

            // --- Line 1: Gyro angle ---
            int angle_rounded = (int)roundf(turn_angle_temp);
            snprintf(line1, sizeof(line1), "Ang:%4d deg", angle_rounded);

            // --- Line 2: Ultrasonic distance ---
            if (dist_valid && dist_age_ms < 300)
                snprintf(line2, sizeof(line2), "US: %5.1f cm", dist_cm);
            else
                snprintf(line2, sizeof(line2), "US: --- cm");

            // --- Line 3: Left IR sensor ---
            if (g_irLeftDist > 0.0f)
                snprintf(line3, sizeof(line3), "IR-L: %5.1f cm", g_irLeftDist);
            else
                snprintf(line3, sizeof(line3), "IR-L: No Obj");

            // --- Line 4: Right IR sensor ---
            if (g_irRightDist > 0.0f)
                snprintf(line4, sizeof(line4), "IR-R: %5.1f cm", g_irRightDist);
            else
                snprintf(line4, sizeof(line4), "IR-R: No Obj");

            // --- Line 5: Optional status info (age or status) ---
            if (dist_valid)
                snprintf(line5, sizeof(line5), "Age:%lu ms", dist_age_ms);
            else
                snprintf(line5, sizeof(line5), "US: No Signal");

            // --- Display all lines ---
            OLED_Clear();
            OLED_ShowString(0, 0,  (uint8_t*)line1);  // Gyro
            OLED_ShowString(0, 12, (uint8_t*)line2);  // Ultrasonic
            OLED_ShowString(0, 24, (uint8_t*)line3);  // IR Left
            OLED_ShowString(0, 36, (uint8_t*)line4);  // IR Right
            OLED_ShowString(0, 48, (uint8_t*)line5);  // Status
            OLED_Refresh_Gram();
        }

        osDelay(5);  // prevent too-frequent gyro reads
    }
}
/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* USER CODE BEGIN 5 */
  /* Infinite loop */
  for(;;)
  {
	//The LED is used to check the thing
	HAL_GPIO_TogglePin(LED_3_GPIO_Port, LED_3_Pin);
    osDelay(500);
  }
  /* USER CODE END 5 */
}

/* USER CODE BEGIN Header_StartGyroTask */
/**
* @brief Function implementing the GyroTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartGyroTask */
//void StartGyroTask(void *argument)
//{
//  /* USER CODE BEGIN StartGyroTask */
////  /* Infinite loop */
////  for(;;)
////  {
////    osDelay(1);
////  }
//  /* USER CODE END StartGyroTask */
//}

/* USER CODE BEGIN Header_StartMotorTask */
/**
* @brief Function implementing the MotorTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartMotorTask */
//void StartMotorTask(void *argument)
//{
//  /* USER CODE BEGIN StartMotorTask */
////  /* Infinite loop */
////  for(;;)
////  {
////    osDelay(1);
////  }
//  /* USER CODE END StartMotorTask */
//}

/* USER CODE BEGIN Header_StartServoTask */
/**
* @brief Function implementing the ServoTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartServoTask */
//void StartServoTask(void *argument)
//{
//  /* USER CODE BEGIN StartServoTask */
////  /* Infinite loop */
////  for(;;)
////  {
////    osDelay(1);
////  }
//  /* USER CODE END StartServoTask */
//}

/* USER CODE BEGIN Header_StartUARTTask */
/**
* @brief Function implementing the UARTTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartUARTTask */
void StartUARTTask(void *argument)
{
  /* USER CODE BEGIN StartUARTTask */
//  /* Infinite loop */
//  for(;;)
//  {
//    osDelay(1);
//  }
  /* USER CODE END StartUARTTask */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
